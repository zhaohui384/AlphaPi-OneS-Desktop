#include "st7789.h"

#include <cstring>

#include "driver/ledc.h"
#include "driver/spi_master.h"
#include "esp_heap_caps.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_commands.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_panel_st7789.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "ascii_font.h"
#include "cn_font.h"
#include "radio_config.h"

namespace radio {
namespace {

constexpr char kTag[] = "ST7735-OneS";
void SendSt7735InitSequence(esp_lcd_panel_io_handle_t io) {
  static const uint8_t kFrameRate[] = {0x01, 0x2c, 0x2d};
  static const uint8_t kFrameRate3[] = {0x01, 0x2c, 0x2d, 0x01, 0x2c, 0x2d};
  static const uint8_t kInversion[] = {0x07};
  static const uint8_t kPower1[] = {0xa2, 0x02, 0x84};
  static const uint8_t kPower2[] = {0xc5};
  static const uint8_t kPower3[] = {0x0a, 0x00};
  static const uint8_t kPower4[] = {0x8a, 0x2a};
  static const uint8_t kPower5[] = {0x8a, 0xee};
  static const uint8_t kVcom[] = {0x0e};
  static const uint8_t kMadctl[] = {0xc8};
  static const uint8_t kColorMode[] = {0x05};
  static const uint8_t kColumns[] = {0x00, 0x00, 0x00, 0x7f};
  static const uint8_t kRows[] = {0x00, 0x00, 0x00, 0x9f};
  static const uint8_t kGammaPos[] = {
      0x0f, 0x1a, 0x0f, 0x18, 0x2f, 0x28, 0x20, 0x22,
      0x1f, 0x1b, 0x23, 0x37, 0x00, 0x07, 0x02, 0x10,
  };
  static const uint8_t kGammaNeg[] = {
      0x0f, 0x1b, 0x0f, 0x17, 0x33, 0x2c, 0x29, 0x2e,
      0x30, 0x30, 0x39, 0x3f, 0x00, 0x07, 0x03, 0x10,
  };

  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, LCD_CMD_SWRESET, nullptr, 0));
  vTaskDelay(pdMS_TO_TICKS(150));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, LCD_CMD_SLPOUT, nullptr, 0));
  vTaskDelay(pdMS_TO_TICKS(120));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, 0xb1, kFrameRate, sizeof(kFrameRate)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, 0xb2, kFrameRate, sizeof(kFrameRate)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, 0xb3, kFrameRate3, sizeof(kFrameRate3)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, 0xb4, kInversion, sizeof(kInversion)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, 0xc0, kPower1, sizeof(kPower1)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, 0xc1, kPower2, sizeof(kPower2)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, 0xc2, kPower3, sizeof(kPower3)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, 0xc3, kPower4, sizeof(kPower4)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, 0xc4, kPower5, sizeof(kPower5)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, 0xc5, kVcom, sizeof(kVcom)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, LCD_CMD_INVOFF, nullptr, 0));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, LCD_CMD_MADCTL, kMadctl, sizeof(kMadctl)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, LCD_CMD_COLMOD, kColorMode, sizeof(kColorMode)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, LCD_CMD_CASET, kColumns, sizeof(kColumns)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, LCD_CMD_RASET, kRows, sizeof(kRows)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, 0xe0, kGammaPos, sizeof(kGammaPos)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, 0xe1, kGammaNeg, sizeof(kGammaNeg)));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, LCD_CMD_DISPON, nullptr, 0));
  vTaskDelay(pdMS_TO_TICKS(100));
  ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io, LCD_CMD_NORON, nullptr, 0));
  vTaskDelay(pdMS_TO_TICKS(10));
}


// xiaozhi-esp32 config.h 实机验证引脚
constexpr int kSpiHost = SPI2_HOST;
constexpr int kSck = kDisplaySck;
constexpr int kMosi = kDisplayMosi;
constexpr int kMiso = kDisplayMiso;
constexpr gpio_num_t kCs = static_cast<gpio_num_t>(kDisplayCs);
constexpr gpio_num_t kDc = static_cast<gpio_num_t>(kDisplayDc);
constexpr gpio_num_t kRst = static_cast<gpio_num_t>(kDisplayReset);
constexpr gpio_num_t kBl = static_cast<gpio_num_t>(kDisplayBacklight);

constexpr int kPanelWidth = 128;   // ST7789 物理宽
constexpr int kPanelHeight = 160;  // ST7789 物理高（含偏移）

constexpr uint16_t kColorBlack = 0x0000;
constexpr uint16_t kColorWhite = 0xFFFF;

}  // namespace

bool Display::Init() {
    if (initialized_) {
        return true;
    }

    // ---- SPI 总线 ----
    spi_bus_config_t bus_cfg = {};
    bus_cfg.sclk_io_num = kSck;
    bus_cfg.mosi_io_num = kMosi;
    bus_cfg.miso_io_num = kMiso;
    bus_cfg.quadwp_io_num = -1;
    bus_cfg.quadhd_io_num = -1;
    bus_cfg.max_transfer_sz = 160 * 128 * 2 + 8;
    esp_err_t err = spi_bus_initialize((spi_host_device_t)kSpiHost, &bus_cfg,
                                       SPI_DMA_CH_AUTO);
    if (err != ESP_OK) {
        ESP_LOGE(kTag, "SPI 总线初始化失败: %s", esp_err_to_name(err));
        return false;
    }

    // ---- SPI panel IO ----
    esp_lcd_panel_io_spi_config_t io_cfg = {};
    io_cfg.cs_gpio_num = kCs;
    io_cfg.dc_gpio_num = kDc;
    io_cfg.spi_mode = 0;
    io_cfg.pclk_hz = 26000000;  // 31.25 MHz（xiaozhi 实测值）
    io_cfg.trans_queue_depth = 4;
    io_cfg.on_color_trans_done = nullptr;
    io_cfg.user_ctx = nullptr;
    io_cfg.lcd_cmd_bits = 8;
    io_cfg.lcd_param_bits = 8;

    esp_lcd_panel_io_handle_t io_handle = nullptr;
    err = esp_lcd_new_panel_io_spi((spi_host_device_t)kSpiHost, &io_cfg,
                                   &io_handle);
    if (err != ESP_OK) {
        ESP_LOGE(kTag, "panel IO 创建失败: %s", esp_err_to_name(err));
        return false;
    }

    // ---- ST7789 面板 ----
    esp_lcd_panel_dev_config_t panel_cfg = {};
    panel_cfg.reset_gpio_num = kRst;
    panel_cfg.rgb_ele_order = LCD_RGB_ELEMENT_ORDER_RGB;
    panel_cfg.bits_per_pixel = 16;
    panel_cfg.flags.reset_active_high = 0;

    esp_lcd_panel_handle_t panel = nullptr;
    err = esp_lcd_new_panel_st7789(io_handle, &panel_cfg, &panel);
    if (err != ESP_OK) {
        ESP_LOGE(kTag, "ST7789 面板创建失败: %s", esp_err_to_name(err));
        return false;
    }

    // xiaozhi board 的等效配置：swap_xy + mirror(true,false) => MADCTL 0x60
    // （esp_lcd_panel_swap_xy/mirror 会自动计算并发送 MADCTL，无需手动设置）
    esp_lcd_panel_reset(panel);
    esp_lcd_panel_init(panel);
    SendSt7735InitSequence(io_handle);
    esp_lcd_panel_invert_color(panel, false);
    esp_lcd_panel_swap_xy(panel, true);
    esp_lcd_panel_mirror(panel, true, false);
    esp_lcd_panel_disp_on_off(panel, true);

    // ---- 背光 PWM（LEDC，GPIO37）----
    ledc_timer_config_t ledc_timer = {};
    ledc_timer.speed_mode = LEDC_LOW_SPEED_MODE;
    ledc_timer.duty_resolution = LEDC_TIMER_8_BIT;
    ledc_timer.timer_num = LEDC_TIMER_0;
    ledc_timer.freq_hz = 5000;
    ledc_timer.clk_cfg = LEDC_AUTO_CLK;
    ledc_timer_config(&ledc_timer);

    ledc_channel_config_t ledc_channel = {};
    ledc_channel.gpio_num = kBl;
    ledc_channel.speed_mode = LEDC_LOW_SPEED_MODE;
    ledc_channel.channel = LEDC_CHANNEL_0;
    ledc_channel.intr_type = LEDC_INTR_DISABLE;
    ledc_channel.timer_sel = LEDC_TIMER_0;
    ledc_channel.duty = 128;  // 50%
    ledc_channel.hpoint = 0;
    ledc_channel_config(&ledc_channel);

    panel_ = panel;
    initialized_ = true;

    // 帧缓冲：全部绘制先在内存完成，Flush() 时整屏一次 SPI 传输。
    // 40KB 放 PSRAM（2MB 足够），彻底避免逐像素 SPI 锁竞争导致的崩溃。
    fb_ = static_cast<uint16_t*>(heap_caps_malloc(
        static_cast<size_t>(kDisplayWidth) * kDisplayHeight * sizeof(uint16_t),
        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (fb_ == nullptr) {
        ESP_LOGE(kTag, "帧缓冲分配失败");
        return false;
    }
    // 字节序交换缓冲：ST7789 组件大端收像素，fb_ 小端。Flush() 时把
    // fb_ 交换后的数据拷入 swap_buf_ 再提交给异步 DMA；DMA 只读
    // swap_buf_，fb_ 恒为标准 565，彻底避免"原地交换→异步传输→
    // 立即换回"的竞态（DMA 迟读会读到换回的字节，米白底变蓝色条纹）。
    swap_buf_ = static_cast<uint16_t*>(heap_caps_malloc(
        static_cast<size_t>(kDisplayWidth) * kDisplayHeight * sizeof(uint16_t),
        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (swap_buf_ == nullptr) {
        ESP_LOGE(kTag, "交换缓冲分配失败");
        return false;
    }
    FillScreen(kColorBlack);
    Flush();

    ESP_LOGI(kTag, "ST7789 初始化完成 (160x128, framebuffer)");
    return true;
}

void Display::Flush() {
    if (!initialized_ || fb_ == nullptr || swap_buf_ == nullptr) {
        return;
    }
    // ST7789 组件默认按大端接收 RGB565（RAMCTL 0xf0 big endian），
    // 而 fb_ 是 uint16_t 小端内存。SPI 直发会每像素高低字节颠倒，
    // 导致颜色通道错乱（浅米色 #F2E8D8 显示成青蓝色 0x5BF7）。
    // 这里把交换后的像素拷入 swap_buf_ 再提交：
    // esp_lcd_panel_draw_bitmap 是异步的（spi_device_queue_trans 排队即返回），
    // DMA 稍后才读取缓冲。若原地交换 fb_ 并立即换回，DMA 迟读会读到
    // 已换回的小端字节，产生蓝色条纹闪烁。swap_buf_ 独立且每次整屏
    // 重绘周期（250ms）远大于传输时间（~10ms），覆盖前必然传输完毕。
    const int n = kDisplayWidth * kDisplayHeight;
    const uint16_t* src = fb_;
    uint16_t* dst = swap_buf_;
    for (int i = 0; i < n; ++i) {
        dst[i] = static_cast<uint16_t>((src[i] >> 8) | (src[i] << 8));
    }
    esp_lcd_panel_draw_bitmap((esp_lcd_panel_handle_t)panel_, 0, 0,
                              kDisplayWidth, kDisplayHeight, swap_buf_);
}

void Display::FillScreen(uint16_t color) {
    FillRect(0, 0, kDisplayWidth, kDisplayHeight, color);
}

void Display::FillRect(int x, int y, int w, int h, uint16_t color) {
    if (!initialized_ || fb_ == nullptr || w <= 0 || h <= 0) {
        return;
    }
    // 裁剪到屏幕范围
    if (x < 0) {
        w += x;
        x = 0;
    }
    if (y < 0) {
        h += y;
        y = 0;
    }
    if (x + w > kDisplayWidth) {
        w = kDisplayWidth - x;
    }
    if (y + h > kDisplayHeight) {
        h = kDisplayHeight - y;
    }
    if (w <= 0 || h <= 0) {
        return;
    }

    // 写帧缓冲（内存操作，无 SPI 竞争）
    for (int row = 0; row < h; ++row) {
        uint16_t* line = fb_ + (y + row) * kDisplayWidth + x;
        for (int col = 0; col < w; ++col) {
            line[col] = color;
        }
    }
}

void Display::DrawPixel(int x, int y, uint16_t color) {
    if (!initialized_ || fb_ == nullptr) {
        return;
    }
    if (x < 0 || x >= kDisplayWidth || y < 0 || y >= kDisplayHeight) {
        return;
    }
    fb_[y * kDisplayWidth + x] = color;
}

void Display::ClearRow(int y, int height) {
    FillRect(0, y, kDisplayWidth, height, kColorBlack);
}

void Display::SetBacklight(int percent) {
    if (percent < 0) {
        percent = 0;
    }
    if (percent > 100) {
        percent = 100;
    }
    const uint32_t duty = (percent * 255) / 100;
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, duty);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
}

void Display::DrawGlyph(int x, int y, const uint8_t* data, int width,
                        int height, uint16_t color, uint16_t bg_color) {
    if (!initialized_ || fb_ == nullptr) {
        return;
    }
    const int bytes_per_row = width / 8;
    for (int row = 0; row < height; ++row) {
        for (int byte = 0; byte < bytes_per_row; ++byte) {
            uint8_t bits = data[row * bytes_per_row + byte];
            for (int bit = 0; bit < 8; ++bit) {
                const bool on = (bits & (0x80 >> bit)) != 0;
                const int px = x + byte * 8 + bit;
                const int py = y + row;
                if (px < 0 || px >= kDisplayWidth || py < 0 ||
                    py >= kDisplayHeight) {
                    continue;
                }
                fb_[py * kDisplayWidth + px] = on ? color : bg_color;
            }
        }
    }
}

int Display::DrawChar(int x, int y, uint32_t codepoint, uint16_t color,
                      uint16_t bg_color) {
    if (codepoint < 0x80) {
        // ASCII 8x16
        if (codepoint < 0x20 || codepoint > 0x7E) {
            codepoint = ' ';
        }
        const uint8_t* glyph = kAscii8x16[codepoint - 0x20];
        DrawGlyph(x, y, glyph, 8, 16, color, bg_color);
        return x + 8;
    }
    // 中文（UTF-8 3 字节）—— 查子集字库
    for (int i = 0; i < kCnFontCount; ++i) {
        // utf8 字段存的是转义后的字节序列，直接按字符串比较
        if (std::strlen(kCnFont[i].utf8) == 3 &&
            static_cast<unsigned char>(kCnFont[i].utf8[0]) ==
                ((codepoint >> 16) & 0xFF) &&
            static_cast<unsigned char>(kCnFont[i].utf8[1]) ==
                ((codepoint >> 8) & 0xFF) &&
            static_cast<unsigned char>(kCnFont[i].utf8[2]) ==
                (codepoint & 0xFF)) {
            DrawGlyph(x, y, kCnFont[i].data, 16, 16, color, bg_color);
            return x + 16;
        }
    }
    // 未收录：画空心方框占位。直接写入帧缓冲，随 Flush() 整屏统一传输。
    // （之前逐像素 esp_lcd_panel_draw_bitmap 直发有两个问题：单像素
    // 传输是异步排队的，且引用了栈上局部变量 c_be，DMA 稍后读取时
    // 该地址已被复用，颜色会错乱。改走帧缓冲后无此隐患。）
    for (int row = 0; row < 16; ++row) {
        for (int col = 0; col < 16; ++col) {
            const bool edge = (row == 0 || row == 15 || col == 0 || col == 15);
            const int px = x + col;
            const int py = y + row;
            if (px < 0 || px >= kDisplayWidth || py < 0 ||
                py >= kDisplayHeight) {
                continue;
            }
            fb_[py * kDisplayWidth + px] = edge ? color : bg_color;
        }
    }
    return x + 16;
}

int Display::DrawCharScaled(int x, int y, char c, uint16_t color,
                            uint16_t bg_color, int scale) {
    if (!initialized_ || fb_ == nullptr) {
        return x;
    }
    if (scale <= 1) {
        return DrawChar(x, y, static_cast<uint32_t>(c), color, bg_color);
    }
    if (c < 0x20 || c > 0x7E) {
        c = ' ';
    }
    const uint8_t* glyph = kAscii8x16[c - 0x20];
    for (int row = 0; row < 16; ++row) {
        const uint8_t bits = glyph[row];
        for (int bit = 0; bit < 8; ++bit) {
            const bool on = (bits & (0x80 >> bit)) != 0;
            const int px = x + bit * scale;
            const int py = y + row * scale;
            FillRect(px, py, scale, scale, on ? color : bg_color);
        }
    }
    return x + 8 * scale;
}

int Display::DrawText(int x, int y, const char* text, uint16_t color,
                      uint16_t bg_color) {
    const unsigned char* p =
        reinterpret_cast<const unsigned char*>(text);
    while (*p != '\0') {
        if (*p < 0x80) {
            x = DrawChar(x, y, *p, color, bg_color);
            ++p;
        } else if ((*p & 0xE0) == 0xE0 && p[1] && p[2]) {
            const uint32_t cp = (static_cast<uint32_t>(p[0]) << 16) |
                                (static_cast<uint32_t>(p[1]) << 8) |
                                p[2];
            x = DrawChar(x, y, cp, color, bg_color);
            p += 3;
        } else {
            ++p;  // 非法字节跳过
        }
    }
    return x;
}

}  // namespace radio
