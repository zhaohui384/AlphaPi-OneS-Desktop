#pragma once
#include "desktop_home_assets.h"
#include "desktop_calendar.h"
#include "st7789.h"
#include <algorithm>
#include <cstdio>
#include <string>

namespace desktop_home {
inline uint16_t Color(int r,int g,int b){return ((r>>3)<<11)|((g>>2)<<5)|(b>>3);}
inline uint32_t Next(const char*& p){
    uint8_t c=*p++;if(c<128)return c;
    int n=(c&0xe0)==0xc0?1:(c&0xf0)==0xe0?2:0;
    uint32_t result=c&(n==1?31:15);
    if(!n)return '?';
    while(n--){if(!*p)return '?';result=(result<<6)|(*p++&63);}
    return result;
}
inline const HomeGlyph* Glyph(uint32_t c){
    auto it=std::lower_bound(std::begin(home_glyphs),std::end(home_glyphs),c,
        [](const HomeGlyph& g,uint32_t c){return g.code<c;});
    return it!=std::end(home_glyphs)&&it->code==c?it:nullptr;
}
inline int Width(const std::string& value){
    int width=0;const char* p=value.c_str();
    while(*p){const auto* g=Glyph(Next(p));if(g)width+=g->advance;}
    return width;
}
inline int Text(radio::Display& lcd,int x,int y,const std::string& value,uint16_t color,int right=159){
    const char* p=value.c_str();
    while(*p){const auto* g=Glyph(Next(p));if(!g)continue;
        if(x+g->advance>right)break;
        for(int yy=0;yy<12;yy++)for(int xx=0;xx<g->width;xx++)
            if(x+xx<right&&(g->rows[yy]&(1u<<(g->width-1-xx))))lcd.DrawPixel(x+xx,y+yy,color);
        x+=g->advance;
    }
    return x;
}
template<typename T,size_t N>
inline int Digits(radio::Display& lcd,int x,int y,const char* value,const T (&glyphs)[N],uint16_t color){
    for(;*value;value++){
        int index=*value==':'?10:*value=='-'?11:*value-'0';
        if(index<0||index>=static_cast<int>(N))continue;
        const auto& g=glyphs[index];
        for(size_t yy=0;yy<std::size(g.rows);yy++)for(int xx=0;xx<g.width;xx++)
            if(g.rows[yy]&(1u<<(g.width-1-xx)))lcd.DrawPixel(x+xx,y+yy,color);
        x+=g.advance;
    }
    return x;
}
inline void Circle(radio::Display& lcd,int cx,int cy,int r,uint16_t color){
    for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++)if(x*x+y*y<=r*r)lcd.DrawPixel(cx+x,cy+y,color);
}
inline void WeatherIcon(radio::Display& lcd,const std::string& condition,bool valid){
    const auto cloud=Color(211,219,235),sun=Color(255,207,105),rain=Color(133,180,238);
    if(valid&&(condition=="晴"||condition=="多云")){
        Circle(lcd,141,42,7,sun);
        for(int a=-1;a<=1;a++)for(int b=-1;b<=1;b++)if(a||b)
            lcd.FillRect(141+a*10,42+b*10,2,2,sun);
        if(condition=="晴")return;
    }
    const auto color=valid?cloud:Color(110,124,151);
    Circle(lcd,134,44,6,color);Circle(lcd,142,42,8,color);Circle(lcd,150,47,5,color);
    lcd.FillRect(129,45,23,8,color);
    if(valid&&condition.find("雨")!=std::string::npos){
        lcd.FillRect(134,55,1,3,rain);lcd.FillRect(141,55,1,3,rain);lcd.FillRect(148,55,1,3,rain);
    }else if(valid&&condition=="雪"){
        for(int x:{134,142,150}){lcd.FillRect(x,55,1,3,cloud);lcd.FillRect(x-1,56,3,1,cloud);}
    }
}
inline void Draw(radio::Display& lcd,const tm& local,bool valid,const std::string& city,
                 const std::string& condition,bool weather_valid,double temperature,int signal){
    const auto white=Color(245,247,255),muted=Color(183,192,216),accent=Color(196,177,240);
    char buffer[96];
    if(valid){
        static const char* week[]={"日","一","二","三","四","五","六"};
        snprintf(buffer,sizeof(buffer),"%d月%d日  星期%s",local.tm_mon+1,local.tm_mday,week[local.tm_wday]);
    }else snprintf(buffer,sizeof(buffer),"等待网络校时");
    Text(lcd,9,4,buffer,muted,132);
    for(int i=0;i<4;i++)lcd.FillRect(139+i*3,12-(i+1)*2,2,(i+1)*2,
        i<signal?Color(170,184,207):Color(48,61,83));
    Text(lcd,9,26,valid?desktop_calendar::LunarText(local):"农历待校时",accent,78);
    Text(lcd,79,26,city,muted,122);
    if(valid)snprintf(buffer,sizeof(buffer),"%02d:%02d",local.tm_hour,local.tm_min);
    else snprintf(buffer,sizeof(buffer),"--:--");
    const int end=Digits(lcd,9,40,buffer,home_clock_digits,white);
    if(valid)snprintf(buffer,sizeof(buffer),":%02d",local.tm_sec);else snprintf(buffer,sizeof(buffer),":--");
    Digits(lcd,end+2,40+home_clock_height-home_seconds_height,buffer,home_seconds_digits,accent);
    WeatherIcon(lcd,condition,weather_valid);
    std::string label;
    if(weather_valid){
        snprintf(buffer,sizeof(buffer),"%.0f°C",temperature);label=condition+" "+buffer;
        if(Width(label)>37){snprintf(buffer,sizeof(buffer),"%.0f°",temperature);label=condition+" "+buffer;}
        if(Width(label)>37){
            std::string brief=condition.find("雨")!=std::string::npos?"雨":condition.substr(0,3);
            label=brief+" "+buffer;
        }
    }else label="-- --°";
    Text(lcd,std::max(121,158-Width(label)),62,label,Color(217,223,236),159);
}
}
