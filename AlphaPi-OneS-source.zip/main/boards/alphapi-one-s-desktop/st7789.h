#pragma once

// ST7789 160x128 屏幕驱动 —— AlphaPi One (ESP32-S3) 独立版
//
// 引脚与初始化参数取自 xiaozhi-esp32 boards/alphapi/alphapi-s3/config.h
// （已实机验证）：
//   SPI2: SCK=41, MOSI=42, MISO=47, CS=38, DC=40, RST=39, BL=37(背光 PWM)
//   ST7789: pclk=31.25MHz, swap_xy=true, mirror(true,false) => MADCTL 0x60
//   物理 128x160 -> 逻辑 160x128（横屏），RGB565
//
// 文本渲染：
//   - ASCII 用 8x16 点阵（ascii_font.h，95 字符）
//   - 中文用 16x16 点阵子集（cn_font.h，电台名用字）
//   - 未收录的中文显示为 □

#include <cstdint>
#include <cstddef>

namespace radio {

class Display {
public:
    Display() = default;

    bool Init();

    void FillScreen(uint16_t color);
    void FillRect(int x, int y, int w, int h, uint16_t color);
    void DrawPixel(int x, int y, uint16_t color);

    // 坐标基准：逻辑横屏 160x128（x 向右, y 向下）
    int width() const { return 160; }
    int height() const { return 128; }

    // 文本渲染（UTF-8 混合：ASCII + 已收录汉字）
    // 返回下一个可用的 x 坐标
    int DrawText(int x, int y, const char* text, uint16_t color,
                 uint16_t bg_color);
    int DrawChar(int x, int y, uint32_t codepoint, uint16_t color,
                 uint16_t bg_color);

    // 放大的 ASCII 字符（8x16 点阵按 scale 倍绘制，如 scale=2 -> 16x32）。
    // 用于大号台号等图形化元素；仅支持 ASCII（0x20..0x7E）。
    int DrawCharScaled(int x, int y, char c, uint16_t color,
                       uint16_t bg_color, int scale);

    // 整行清屏（指定高度）
    void ClearRow(int y, int height);

    // 把帧缓冲一次性整屏输出到 LCD（内部 160x128 RGB565）
    void Flush();

    void SetBacklight(int percent);  // 0-100

private:
    void DrawGlyph(int x, int y, const uint8_t* data, int width, int height,
                   uint16_t color, uint16_t bg_color);

    void* panel_ = nullptr;   // esp_lcd_panel_handle_t
    uint16_t* fb_ = nullptr;  // 帧缓冲（PSRAM，160*128，恒为标准 RGB565 小端）
    uint16_t* swap_buf_ = nullptr;  // 字节序交换缓冲（PSRAM，DMA 只读此缓冲）
    bool initialized_ = false;
};

}  // namespace radio
