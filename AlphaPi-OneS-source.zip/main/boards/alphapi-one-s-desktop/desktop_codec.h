#include "esp_timer.h"
#include <atomic>
#include <algorithm>
#include <cmath>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#pragma once
#include "audio_codec.h"
#include "n32_audio.h"
#include "desktop_state.h"
class DesktopCodec final : public AudioCodec {
public:
 radio::N32Audio audio;
 std::atomic<uint32_t> mic_frames{0},mic_errors{0};
 std::atomic<int64_t> mic_frame_us{0};
 std::atomic<int> mic_peak{0};
 std::atomic<uint32_t> mic_samples{0},output_samples{0};
 std::atomic<int> output_peak{0};
 // Supplied original firmware 0x4202b235 passes 24000 for BOTH codec rates.
 // AudioService resamples the hardware's 24kHz capture to 16kHz for Opus.
 DesktopCodec(){input_sample_rate_=24000;output_sample_rate_=24000;input_channels_=output_channels_=1;duplex_=false;input_gain_=0.0f;audio.Init();}
 // Persist once after the user releases the volume keys, not in the audio path.
 void SetOutputVolume(int value)override{output_volume_=std::clamp(value,0,100);audio.SetVolume(value);}
 void EnableInput(bool enabled)override{if(enabled!=input_enabled_){if(desktop_page.load()==2)audio.Stop();input_enabled_=enabled;}}
 void EnableOutput(bool enabled)override{if(enabled!=output_enabled_){if(desktop_page.load()==2)audio.Stop();output_enabled_=enabled;}}
protected:
 float dc_=0;
 TickType_t capture_cadence_=0;
 bool cadence_active_=false;
 int Write(const int16_t* data,int samples)override{
  if(desktop_page.load()!=2)return samples;
  int peak=0;for(int i=0;i<samples;i++)peak=std::max(peak,std::abs(static_cast<int>(data[i])));
  output_peak=peak;output_samples+=samples;
  return audio.Write(data,samples);
 }
 int Read(int16_t* data,int samples)override{
  if(desktop_page.load()!=2){cadence_active_=false;vTaskDelay(pdMS_TO_TICKS(20));return 0;}
  int64_t capture_start=esp_timer_get_time();
  if(!cadence_active_){capture_cadence_=xTaskGetTickCount();cadence_active_=true;}
  int total=0;
  while(total<samples){
   int n=audio.ReadMic(data+total,samples-total);
   if(n<0){mic_errors++;break;}
   if(n==0){vTaskDelay(pdMS_TO_TICKS(10));}
   else total+=n;
   // The FIFO's returned count determines availability; never invent samples or
   // discard a valid short packet. Bound the assembly wait if the device stops.
   if(esp_timer_get_time()-capture_start>200000)break;
  }
  if(total<samples){mic_errors++;cadence_active_=false;vTaskDelay(1);return 0;}
  const float gain=std::pow(10.0f,input_gain_/20.0f);
  int peak=0;
  for(int i=0;i<total;i++){
   dc_+=(static_cast<float>(data[i])-dc_)/512.0f;
   float value=(data[i]-dc_)*gain;
   data[i]=static_cast<int16_t>(std::clamp(value,-32000.0f,32000.0f));
   peak=std::max(peak,std::abs(static_cast<int>(data[i])));
  }
  mic_peak=peak;mic_frame_us=esp_timer_get_time()-capture_start;mic_frames++;mic_samples+=total;
  // Input runs at priority 8. Release CPU time until the next real capture
  // deadline instead of immediately polling again ahead of lower priority UI.
  const TickType_t period=std::max<TickType_t>(1,pdMS_TO_TICKS(total*1000/input_sample_rate_));
  if(xTaskGetTickCount()-capture_cadence_>period*4)capture_cadence_=xTaskGetTickCount();
  vTaskDelayUntil(&capture_cadence_,period);
  return total;
 }
};

