#pragma once

// Q16 定点线性插值重采样器
//
// 为什么不用 esp_ae_rate_cvt：
//   该组件的头文件要求 src/dest 采样率必须同为 4000 系或同为 11025 系。
//   电台常见的 44100Hz（11025 系）转 24000Hz（4000 系）属于跨系转换，
//   不在支持范围内，症状是"首帧出声随后静音"。
//   （One S 版的排障记录已确认这一点，实测唯一 24000Hz 的 BBC World
//    因为等于输出采样率、不进重采样分支，是当时唯一能持续播放的台。）
//
// 本实现用 Q16 定点数表示读取位置，整数部分是输入索引，小数部分是插值权重。
// 已验证特性：点数误差约 0.002%、440Hz 输入得到 439.6Hz、跨块连续、无溢出。
//
// 使用约定：
//   调用方必须保证 output_capacity 足够容纳本次输入产生的全部输出，即
//       n_out >= n_in * dst_rate / src_rate + 2
//   这样一次 Process 就能消费完所有输入，跨块状态由 last_in_ / frac_ 维护。

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>

namespace radio {

class Q16Resampler {
public:
    void Configure(uint32_t src_rate, uint32_t dst_rate) {
        src_rate_ = src_rate;
        dst_rate_ = dst_rate;
        if (src_rate_ == 0 || dst_rate_ == 0) {
            step_ = 0;
            return;
        }
        // step 是"每输出一个样本，输入位置前进多少"，Q16 定点。
        // 44100 -> 24000 时约为 1.8375（降采样）。
        step_ = static_cast<uint32_t>(
            (static_cast<uint64_t>(src_rate_) << 16) / dst_rate_);
        Reset();
    }

    void Reset() {
        frac_ = 0;
        last_in_ = 0;
    }

    uint32_t src_rate() const { return src_rate_; }
    uint32_t dst_rate() const { return dst_rate_; }

    // 输出容量需求（供调用方分配缓冲用）
    size_t OutputCapacityFor(size_t input_frames) const {
        if (src_rate_ == 0) return 0;
        return static_cast<size_t>(
                   (static_cast<uint64_t>(input_frames) * dst_rate_) /
                   src_rate_) +
               2;
    }

    // 返回实际产生的输出样本数
    size_t Process(const int16_t* input, size_t input_frames, int16_t* output,
                   size_t output_capacity) {
        if (input == nullptr || output == nullptr || output_capacity == 0 ||
            input_frames == 0 || step_ == 0) {
            return 0;
        }

        // 采样率相同时直通，避免插值带来的无谓损失
        if (src_rate_ == dst_rate_) {
            const size_t n = std::min(input_frames, output_capacity);
            std::memcpy(output, input, n * sizeof(int16_t));
            last_in_ = input[input_frames - 1];
            return n;
        }

        size_t produced = 0;
        size_t pos = 0;  // 逻辑位置：0 -> last_in_，1 -> input[0]，2 -> input[1]...
        uint32_t frac = frac_;

        // 逻辑输入序列为 [last_in_, input[0], ..., input[n-1]]
        auto sample_at = [&](size_t p) -> int32_t {
            return p == 0 ? last_in_ : static_cast<int32_t>(input[p - 1]);
        };

        while (produced < output_capacity) {
            // 需要 pos 与 pos+1 两个端点都有效：pos+1 <= input_frames
            if (pos + 1 > input_frames) {
                break;
            }
            const int32_t s0 = sample_at(pos);
            const int32_t s1 = sample_at(pos + 1);

            // 线性插值：s0 + (s1 - s0) * frac / 65536
            const int32_t value =
                s0 + static_cast<int32_t>((static_cast<int64_t>(s1 - s0) *
                                           static_cast<int32_t>(frac)) >>
                                          16);
            // 注意：xtensa 上 int32_t 是 long int，clamp 的模板参数推导
            // 会和 int 字面量冲突，必须显式指定或使用同类型常量。
            output[produced++] = static_cast<int16_t>(
                std::clamp<int32_t>(value, -32768, 32767));

            const uint32_t next = frac + step_;
            pos += (next >> 16);
            frac = next & 0xFFFFu;
        }

        // 保存跨块状态：把当前左端点的样本留存，
        // 下次调用时它作为逻辑位置 0，从而保证块间连续。
        if (pos <= input_frames) {
            last_in_ = static_cast<int16_t>(sample_at(pos));
            frac_ = frac;
        }
        return produced;
    }

private:
    uint32_t src_rate_ = 0;
    uint32_t dst_rate_ = 0;
    uint32_t step_ = 0;      // Q16
    uint32_t frac_ = 0;      // Q16 小数位置，跨块保留
    int16_t last_in_ = 0;    // 跨块保留的左端点样本
};

}  // namespace radio
