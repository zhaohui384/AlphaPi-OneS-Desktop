#include <ctime>
#include "esp_system.h"
#include "esp_timer.h"
#include "application.h"
#include <algorithm>
#include <cstdlib>
#include "desktop_runtime.h"
#include "desktop_web.h"
#include "esp_netif.h"
#include "cJSON.h"
#include "esp_heap_caps.h"
#include <cstdio>
#include <cstring>
#include <sys/stat.h>
namespace {
std::string Body(httpd_req_t* r){if(r->content_len<=0||r->content_len>4096)return {};std::string body(r->content_len,'\0');int offset=0;while(offset<r->content_len){int n=httpd_req_recv(r,body.data()+offset,r->content_len-offset);if(n<=0)return {};offset+=n;}return body;}
esp_err_t Reply(httpd_req_t* r,const std::string& json,int code=200){httpd_resp_set_type(r,"application/json; charset=utf-8");httpd_resp_set_hdr(r,"Cache-Control","no-store");if(code!=200)httpd_resp_set_status(r,code==400?"400 Bad Request":"500 Internal Server Error");return httpd_resp_send(r,json.c_str(),json.size());}
bool Exists(const char* p){struct stat s;return stat(p,&s)==0;}
esp_err_t Route(httpd_req_t* req){
 auto& self=*DesktopRuntime::instance;std::string path=req->uri;auto q=path.find('?');if(q!=std::string::npos)path.resize(q);
 if(path=="/"){httpd_resp_set_type(req,"text/html; charset=utf-8");httpd_resp_set_hdr(req,"Cache-Control","no-store");return httpd_resp_send(req,desktop_html,HTTPD_RESP_USE_STRLEN);}
 if(path=="/api/weather"){
  if(req->method==HTTP_GET)return Reply(req,self.RegionJson());
  const auto data=Body(req);bool ok=!data.empty()&&self.SaveRegion(data.c_str());return Reply(req,ok?"{\"ok\":true}":"{\"ok\":false,\"error\":\"地区参数不正确\"}",ok?200:400);
 }
 if(path=="/api/regions"){
  char query[256]={},name[160]={};httpd_req_get_url_query_str(req,query,sizeof(query));
  if(httpd_query_key_value(query,"q",name,sizeof(name))!=ESP_OK||strlen(name)<1)return Reply(req,"{\"ok\":false,\"error\":\"请输入城市\"}",400);
  return Reply(req,self.SearchRegions(name));
 }
 if(path=="/api/wifi"){
  if(req->method==HTTP_GET)return Reply(req,self.ScanWifi());
  auto data=Body(req);auto root=cJSON_Parse(data.c_str());auto ssid=cJSON_GetObjectItem(root,"ssid"),pass=cJSON_GetObjectItem(root,"password");
  bool ok=cJSON_IsString(ssid)&&cJSON_IsString(pass)&&strlen(ssid->valuestring)>0&&strlen(ssid->valuestring)<=32&&(strlen(pass->valuestring)==0||(strlen(pass->valuestring)>=8&&strlen(pass->valuestring)<=63));
  if(!ok){cJSON_Delete(root);return Reply(req,"{\"ok\":false,\"error\":\"请检查网络名称和密码长度\"}",400);}
  std::string name=ssid->valuestring,password=pass->valuestring;cJSON_Delete(root);auto result=Reply(req,"{\"ok\":true}");self.ConnectWifi(name,password);return result;
 }
 if(path=="/api/status"){
  // Counters only: audio content is never exposed by the diagnostic endpoint.
  auto root=cJSON_CreateObject();cJSON_AddBoolToObject(root,"connected",desktop_network.load());cJSON_AddNumberToObject(root,"volume",self.codec.audio.volume());cJSON_AddNumberToObject(root,"mic_frames",self.codec.mic_frames.load());cJSON_AddNumberToObject(root,"mic_errors",self.codec.mic_errors.load());cJSON_AddNumberToObject(root,"mic_peak",self.codec.mic_peak.load());cJSON_AddNumberToObject(root,"mic_frame_us",self.codec.mic_frame_us.load());
  cJSON_AddNumberToObject(root,"mic_samples",self.codec.mic_samples.load());cJSON_AddNumberToObject(root,"output_samples",self.codec.output_samples.load());cJSON_AddNumberToObject(root,"output_peak",self.codec.output_peak.load());
  {std::lock_guard<std::recursive_mutex> lock(self.display.mutex);cJSON_AddStringToObject(root,"status",self.display.status.c_str());
   if(Application::GetInstance().GetDeviceState()==kDeviceStateActivating)cJSON_AddStringToObject(root,"connection_detail",self.display.chat.c_str());}
  cJSON_AddNumberToObject(root,"mic_hardware_rate",self.codec.input_sample_rate());
  cJSON_AddNumberToObject(root,"uptime_ms",esp_timer_get_time()/1000);
  cJSON_AddNumberToObject(root,"reset_reason",static_cast<int>(esp_reset_reason()));
  cJSON_AddNumberToObject(root,"ui_loops",self.ui_loops.load());
  cJSON_AddNumberToObject(root,"ui_gap_us",self.ui_gap_us.load());
  cJSON_AddNumberToObject(root,"ui_max_gap_us",self.ui_max_gap_us.load());
  cJSON_AddNumberToObject(root,"render_us",self.render_us.load());
  cJSON_AddNumberToObject(root,"page",desktop_page.load());
  cJSON_AddBoolToObject(root,"radio_running",self.radio.running());
  cJSON_AddNumberToObject(root,"radio_tasks",self.radio.active_tasks());
  cJSON_AddNumberToObject(root,"voice_tasks",Application::GetInstance().GetAudioService().ActiveTasks());
  cJSON_AddBoolToObject(root,"voice_stopped",Application::GetInstance().DesktopVoiceStopped());
  cJSON_AddBoolToObject(root,"radio_paused",self.radio.paused());
  cJSON_AddNumberToObject(root,"radio_state",static_cast<int>(self.radio.state()));
  cJSON_AddNumberToObject(root,"radio_station",self.radio.station_index());
  cJSON_AddNumberToObject(root,"radio_pcm_bytes",self.radio.pcm_available());
  cJSON_AddNumberToObject(root,"heap_internal",heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT));
  cJSON_AddNumberToObject(root,"heap_largest_internal",heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT));
  cJSON_AddNumberToObject(root,"state",Application::GetInstance().GetDeviceState());
  cJSON_AddNumberToObject(root,"key_polls",self.codec.audio.key_polls());
  cJSON_AddNumberToObject(root,"keys",self.codec.audio.cached_keys());
  esp_netif_ip_info_t ip={};auto netif=esp_netif_get_handle_from_ifkey("WIFI_STA_DEF");char text[24]={};if(netif&&esp_netif_get_ip_info(netif,&ip)==ESP_OK)snprintf(text,sizeof(text),IPSTR,IP2STR(&ip.ip));cJSON_AddStringToObject(root,"ip",text);
  time_t now=time(nullptr);tm local={};localtime_r(&now,&local);char timestamp[32];strftime(timestamp,sizeof(timestamp),"%Y-%m-%d %H:%M:%S",&local);cJSON_AddStringToObject(root,"local_time",timestamp);cJSON_AddNumberToObject(root,"utc",static_cast<double>(now));
  {std::lock_guard<std::mutex>lock(self.state_mutex);cJSON_AddBoolToObject(root,"weather_valid",self.have_weather);cJSON_AddStringToObject(root,"city",self.city.c_str());cJSON_AddStringToObject(root,"weather",self.description.c_str());if(self.have_weather)cJSON_AddNumberToObject(root,"temperature",self.temperature);}
  char* json=cJSON_PrintUnformatted(root);auto result=Reply(req,json?json:"{}");free(json);cJSON_Delete(root);return result;
 }
 if(path=="/badge"){
  if(req->content_len!=40968)return Reply(req,"{\"ok\":false,\"error\":\"图片尺寸不正确\"}",400);
  FILE* file=fopen("/data/badge.tmp","wb");if(!file)return Reply(req,"{\"ok\":false,\"error\":\"无法保存图片\"}",500);
  uint8_t block[1024],header[8]={};int total=0;bool valid=true;
  while(total<req->content_len){int n=httpd_req_recv(req,(char*)block,std::min<int>((int)sizeof(block),static_cast<int>(req->content_len-total)));if(n<=0){valid=false;break;}for(int i=0;i<n&&total+i<8;i++)header[total+i]=block[i];if(fwrite(block,1,n,file)!=(size_t)n){valid=false;break;}total+=n;}
  if(fclose(file)!=0)valid=false;
  int w=header[4]|(header[5]<<8),h=header[6]|(header[7]<<8);
  valid=valid&&total==40968&&!memcmp(header,"BDG1",4)&&((w==128&&h==160)||(w==160&&h==128));
  if(valid){
   if(Exists("/data/badge.bin")){remove("/data/badge.old");valid=rename("/data/badge.bin","/data/badge.old")==0;}
   if(valid)valid=rename("/data/badge.tmp","/data/badge.bin")==0;
   if(valid)remove("/data/badge.old");else if(!Exists("/data/badge.bin"))rename("/data/badge.old","/data/badge.bin");
  }
  remove("/data/badge.tmp");if(valid)self.dirty=true;
  return Reply(req,valid?"{\"ok\":true}":"{\"ok\":false,\"error\":\"图片保存失败，原图已保留\"}",valid?200:400);
 }
 httpd_resp_send_404(req);return ESP_OK;
}
}
void DesktopRuntime::StartWeb(){
 if(server)return;
 httpd_config_t cfg=HTTPD_DEFAULT_CONFIG();cfg.max_uri_handlers=12;cfg.stack_size=8192;cfg.recv_wait_timeout=15;cfg.send_wait_timeout=15;
 if(httpd_start(&server,&cfg)!=ESP_OK)return;
 for(const char* path:{"/","/api/weather","/api/regions","/api/wifi","/api/status"}){httpd_uri_t r={};r.uri=path;r.method=HTTP_GET;r.handler=Route;httpd_register_uri_handler(server,&r);}
 for(const char* path:{"/badge","/api/weather","/api/wifi"}){httpd_uri_t r={};r.uri=path;r.method=HTTP_POST;r.handler=Route;httpd_register_uri_handler(server,&r);}
}

