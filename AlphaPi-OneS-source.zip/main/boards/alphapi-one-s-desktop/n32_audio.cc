#include "n32_audio.h"

#include <algorithm>
#include <array>
#include <cstring>
#include <mutex>

#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/uart.h"

#include "radio_config.h"

namespace radio {
namespace {

constexpr char kTag[] = "N32Audio";
static bool g_recording = false;
static bool g_uart_initialized = false;
static std::atomic<uint8_t> g_keys{0xFF};
static std::atomic<int64_t> g_keys_at{0};
static std::atomic<uint32_t> g_key_polls{0};
static int64_t g_key_attempt_at=0; // Access only while holding UartMutex.
// 写寄存器等待应答超时：N32 持续播放时 UART 应答可能晚到，
// 120ms 太紧会导致高频"写失败→重置链路"风暴（实测引发中断看门狗崩溃），放宽到 400ms。
constexpr int kCommandTimeoutMs = 400;

// 与 N32 协处理器通信时统一持有的互斥锁。
// 音频写入、按键查询两方共用，防止抢总线导致音频卡顿。
std::mutex& UartMutex() {
    static std::mutex mutex;
    return mutex;
}

}  // namespace

uint8_t N32Audio::Checksum(const uint8_t* data, size_t length) {
    uint8_t sum = 0;
    for (size_t i = 0; i < length; ++i) {
        sum = static_cast<uint8_t>(sum + data[i]);
    }
    return sum;
}

bool N32Audio::ReadExact(uint8_t* data, size_t length, int timeout_ms) {
    size_t offset = 0;
    while (offset < length) {
        const int received = uart_read_bytes(kUartPort, data + offset,
                                             length - offset,
                                             pdMS_TO_TICKS(timeout_ms));
        if (received <= 0) {
            return false;
        }
        offset += static_cast<size_t>(received);
    }
    return true;
}

bool N32Audio::SendCommand(uint8_t reg, const uint8_t* payload,
                           size_t payload_size, uint8_t* accepted) {
    if (payload_size > kMaxPayloadSize) {
        return false;
    }
    std::array<uint8_t, kMaxPayloadSize + 4> frame = {};
    frame[0] = kWritePrefix;
    frame[1] = reg;
    frame[2] = static_cast<uint8_t>(payload_size);
    if (payload_size > 0) {
        std::memcpy(frame.data() + 3, payload, payload_size);
    }
    frame[payload_size + 3] = Checksum(frame.data(), payload_size + 3);

    const size_t frame_size = payload_size + 4;

    // 写失败 / 应答异常时重试一次：N32 播放中应答可能晚到，
    // 立即判失败会触发"重置播放链路"风暴（见 kCommandTimeoutMs 注释）。
    for (int attempt = 0; attempt < 2; ++attempt) {
        uart_flush_input(kUartPort);
        if (uart_write_bytes(kUartPort, frame.data(), frame_size) !=
            static_cast<int>(frame_size)) {
            continue;
        }

        std::array<uint8_t, 3> ack = {};
        if (ReadExact(ack.data(), ack.size(), kCommandTimeoutMs) &&
            ack[0] == kWriteAck && ack[1] == reg) {
            if (accepted != nullptr) {
                *accepted = ack[2];
            }
            return true;
        }
    }
    return false;
}

bool N32Audio::Init() {
    std::lock_guard<std::mutex> lock(UartMutex());
    if (initialized_) {
        return true;
    }

    if(g_uart_initialized){initialized_=true;return true;}
    const uart_config_t config = {
        .baud_rate = kUartBaudRate,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .rx_flow_ctrl_thresh = 0,
        .source_clk = UART_SCLK_APB,
        .flags = {},
    };
    if (uart_driver_install(kUartPort, 8192, 8192, 0, nullptr, 0) != ESP_OK) {
        ESP_LOGE(kTag, "UART 驱动安装失败");
        return false;
    }
    if (uart_param_config(kUartPort, &config) != ESP_OK) {
        ESP_LOGE(kTag, "UART 参数配置失败");
        return false;
    }
    if (uart_set_pin(kUartPort, kUartTx, kUartRx, UART_PIN_NO_CHANGE,
                     UART_PIN_NO_CHANGE) != ESP_OK) {
        ESP_LOGE(kTag, "UART 引脚设置失败");
        return false;
    }
    uart_flush_input(kUartPort);

    gpio_config_t keys={};keys.pin_bit_mask=(1ULL<<10)|(1ULL<<11)|(1ULL<<12)|(1ULL<<13);
    keys.mode=GPIO_MODE_INPUT;keys.pull_down_en=GPIO_PULLDOWN_ENABLE;gpio_config(&keys);
    vTaskDelay(pdMS_TO_TICKS(2000));
    initialized_ = true;
    g_uart_initialized = true;
    ESP_LOGI(kTag, "UART1 初始化完成 (TX=%d RX=%d baud=%d)",
             kUartTx, kUartRx, kUartBaudRate);
    return true;
}

bool N32Audio::SetHardwareVolumeLocked(int volume) {
    // Verified against the supplied original XiaoZhi firmware, function
    // 0x4202b084: level = (clamp(percent, 0, 100) * 6 + 50) / 100.
    // N32 expects an internal level, never a raw percentage such as 100.
    const uint8_t level = static_cast<uint8_t>(
        (std::clamp(volume, kVolumeMin, kVolumeMax) * 6 + 50) / 100);
    uint8_t accepted = 0;
    return SendCommand(kRegVolume, &level, 1, &accepted);
}

bool N32Audio::Start() {
    std::lock_guard<std::mutex> lock(UartMutex());
    return StartLocked();
}

bool N32Audio::StartLocked() {
    // 调用方必须已持有 UART 互斥锁

    // 半双工：播放前必须先停掉麦克风流
    const uint8_t stop_record = 0;
    if (!SendCommand(kRegAudioControl, &stop_record, 1)) {
        ESP_LOGW(kTag, "停止录音失败（不影响播放，继续）");
    }
    if (!SetHardwareVolumeLocked(100)) {
        ESP_LOGW(kTag, "设置音量失败（不影响播放，继续）");
    }

    // 44 字节标准 WAV 头，向 N32 声明 24000Hz / 8bit / 单声道。
    constexpr uint32_t rate = kOutputSampleRate;
    const std::array<uint8_t, 44> wav_header = {
        'R', 'I', 'F', 'F', 0xff, 0xff, 0xff, 0xff,
        'W', 'A', 'V', 'E', 'f', 'm', 't', ' ',
        0x10, 0x00, 0x00, 0x00,        // fmt chunk size = 16
        0x01, 0x00,                    // PCM
        0x01, 0x00,                    // mono
        static_cast<uint8_t>(rate), static_cast<uint8_t>(rate >> 8),
        static_cast<uint8_t>(rate >> 16), static_cast<uint8_t>(rate >> 24),
        static_cast<uint8_t>(rate), static_cast<uint8_t>(rate >> 8),
        static_cast<uint8_t>(rate >> 16), static_cast<uint8_t>(rate >> 24),
        0x01, 0x00,                    // block align = 1
        0x08, 0x00,                    // 8 bits per sample
        'd', 'a', 't', 'a', 0xff, 0xff, 0xff, 0xff,
    };
    if (!SendCommand(kRegStream, wav_header.data(), wav_header.size())) {
        ESP_LOGE(kTag, "发送 WAV 头失败");
        return false;
    }

    g_recording = false;
    configured_ = true;
    ESP_LOGI(kTag, "播放已就绪：%u Hz / 8-bit unsigned / mono", kOutputSampleRate);
    return true;
}

void N32Audio::Stop() {
    std::lock_guard<std::mutex> lock(UartMutex());
    if (!configured_ && !g_recording) {
        return;
    }
    const uint8_t stop_record = 0;
    SendCommand(kRegAudioControl, &stop_record, 1);
    g_recording = false;
    configured_ = false;
}

void N32Audio::SetVolume(int volume) {
    volume_ = std::clamp(volume, kVolumeMin, kVolumeMax);
    // 音量一律走软件缩放（Write() 内按 volume_ 对 PCM 缩放，真实生效）。
    // 不再每次按键写 N32 硬件寄存器 0x14 —— 高频写硬件音量曾触发链路异常导致重启。
}

int N32Audio::Write(const int16_t* samples, int sample_count) {
    if (samples == nullptr || sample_count <= 0) {
        return 0;
    }

    std::unique_lock<std::mutex> lock(UartMutex());

    // 此处已持有互斥锁，必须调用无锁版本，否则 std::mutex 不可重入会死锁
    if ((!configured_ || g_recording) && !StartLocked()) {
        ESP_LOGE(kTag, "播放未就绪，丢弃 %d 样本", sample_count);
        return 0;
    }

    const size_t total = static_cast<size_t>(sample_count);
    size_t written = 0;
    std::array<uint8_t, kMaxPayloadSize> chunk = {};

    while (written < total) {
        if (!lock.owns_lock()) lock.lock();
        if (!configured_ || g_recording) return static_cast<int>(written);
        const size_t n = std::min(total - written, kMaxPayloadSize);

        // 软件音量：直接对 PCM 样本缩放（N32 寄存器 0x14 在播放流中
        // 可能不响应，软件缩放保证真实音量一定变化；100 时旁路不缩）。
        const int vol = volume_.load();
        for (size_t i = 0; i < n; ++i) {
            int32_t s = samples[written + i];
            if (vol != kVolumeMax) {
                s = (s * vol) / 100;
            }
            // 16-bit signed -> 8-bit unsigned：静音(0) 映射到 128
            chunk[i] = static_cast<uint8_t>((s + 32768) >> 8);
        }

        size_t sent = 0;
        int stalled = 0;
        while (sent < n) {
            PollKeysLocked();
            uint8_t accepted = 0;
            if (!SendCommand(kRegStream, chunk.data() + sent, n - sent,
                             &accepted)) {
                ESP_LOGW(kTag, "PCM 写入失败，重置播放链路");
                configured_ = false;
                return static_cast<int>(written + sent);
            }
            if (accepted == 0) {
                // N32 的接收缓冲满了，短暂等待后重试
                if (++stalled > 20) {
                    ESP_LOGW(kTag, "PCM 写入停滞，重置播放链路");
                    configured_ = false;
                    return static_cast<int>(written + sent);
                }
                // 注意：此时已持有 mutex，等待必须很短（5ms 上限）
                // At CONFIG_FREERTOS_HZ=100, pdMS_TO_TICKS(5) is zero!
                // A zero-tick yield does not let lower priority UI tasks run.
                vTaskDelay(std::max<TickType_t>(1,pdMS_TO_TICKS(5)));
                continue;
            }
            sent += std::min<size_t>(accepted, n - sent);
            stalled = 0;
        }
        written += n;
        // Let key polling use the bus between complete, checksum-protected frames.
        lock.unlock();
        taskYIELD();
    }
    return sample_count;
}

uint8_t N32Audio::ReadKeys() {
    uint8_t keys=(gpio_get_level(GPIO_NUM_13)?4:0)|(gpio_get_level(GPIO_NUM_12)?8:0)|
        (gpio_get_level(GPIO_NUM_11)?2:0)|(gpio_get_level(GPIO_NUM_10)?1:0);
    g_keys=keys;g_keys_at=esp_timer_get_time();g_key_polls++;return keys;
}

uint32_t N32Audio::key_polls() const { return g_key_polls.load(); }
uint8_t N32Audio::cached_keys() const { return g_keys.load(); }

void N32Audio::PollKeysLocked() { ReadKeys(); }

uint8_t N32Audio::ReadKeysLocked() {

    // 读键事务：0x80 <reg> <len> -> 应答 0x81 <reg> <len> <value> <sum>
    const std::array<uint8_t, 3> query = {kReadPrefix, kRegKey, 1};
    std::array<uint8_t, 5> response = {};

    uart_flush_input(kUartPort);
    if (uart_write_bytes(kUartPort, query.data(), query.size()) !=
        static_cast<int>(query.size())) {
        return 0xFF;
    }
    if (!ReadExact(response.data(), response.size(), 20)) {
        return 0xFF;
    }

    const uint8_t checksum = static_cast<uint8_t>(
        response[0] + response[1] + response[2] + response[3]);
    if (response[0] != kReadAck || response[1] != kRegKey ||
        response[2] != 1 || response[4] != checksum) {
        return 0xFF;
    }
    return response[3];
}


int N32Audio::ReadMic(int16_t* samples, int count) {
    if (!samples || count <= 0) return 0;
    std::lock_guard<std::mutex> lock(UartMutex());
    PollKeysLocked();
    if (!g_recording) {
        uint8_t enable=1;
        if (!SendCommand(kRegAudioControl,&enable,1)) return 0;
        configured_=false;g_recording=true;
    }
    const int n=std::min(count,160);
    const std::array<uint8_t,3> query={kReadPrefix,kRegAudioRead,static_cast<uint8_t>(n)};
    std::array<uint8_t,204> response={};
    uart_flush_input(kUartPort);
    uart_write_bytes(kUartPort,query.data(),query.size());
    if (!ReadExact(response.data(),3,50)) return -1;
    const int received=response[2];
    if(response[0]!=kReadAck||response[1]!=kRegAudioRead||received>n) return -1;
    if(!ReadExact(response.data()+3,received+1,50)) return -1;
    if(Checksum(response.data(),received+3)!=response[received+3])return -1;
    for(int i=0;i<received;i++)samples[i]=static_cast<int16_t>((static_cast<int>(response[3+i])-128)*256);
    return received;
}

}  // namespace radio
