#pragma once
#include <string>
#include <mutex>
#include <atomic>
#include <functional>
#include "display.h"
#include "desktop_codec.h"
#include "radio_player.h"
#include "st7789.h"
#include "esp_http_server.h"
#include "board.h"
class DesktopRuntime;
class DesktopDisplay final : public Display {
public:
 radio::Display lcd;
 std::recursive_mutex mutex;
 std::string status,chat,activation,emotion="neutral";
 std::atomic<bool> changed{true};
 DesktopDisplay(){width_=160;height_=128;lcd.Init();}
 void SetStatus(const char* s)override{std::lock_guard<std::recursive_mutex>l(mutex);status=s?s:"";changed=true;}
 void ShowNotification(const char* s,int duration=3000)override{SetStatus(s);}
 void SetChatMessage(const char*,const char* s)override{std::lock_guard<std::recursive_mutex>l(mutex);chat=s?s:"";changed=true;}
 bool SetEmotion(const char* value)override{std::lock_guard<std::recursive_mutex>l(mutex);emotion=value?value:"neutral";changed=true;return true;}
 void ClearChatMessages()override{SetChatMessage("","");}
 void SetupUI()override{setup_ui_called_=true;}
protected:
 bool Lock(int=0)override{mutex.lock();return true;}
 void Unlock()override{mutex.unlock();}
};
class DesktopRuntime {
public:
 static DesktopRuntime* instance;
 DesktopDisplay display;
 DesktopCodec codec;
 radio::RadioPlayer radio;
 NetworkEventCallback network_callback;
 std::mutex state_mutex;
 std::string city="武汉",description="未更新",ssid,pass;
 double latitude=30.59,longitude=114.30;
 double temperature=0;int humidity=-1;
 bool have_weather=false;
 std::atomic<bool> weather_refresh{true};
 std::atomic<bool> dirty{true};
 std::atomic<uint32_t> ui_loops{0},ui_gap_us{0},ui_max_gap_us{0},render_us{0};
 bool ap_enabled=false;
 std::atomic<bool> wifi_scan_active{false};
 bool radio_started=false;
 bool voice_pending=false;
 bool voice_cleanup_pending=false;
 bool radio_pending=false;
 int64_t radio_ready_at=0;
 int64_t voice_ready_at=0;
 int selected=0;
 int64_t volume_overlay_until=0;
 int64_t volume_save_at=0;
 void SetVolume(int value);
 httpd_handle_t server=nullptr;
 DesktopRuntime();
 void StartNetwork();
 void OpenAP();
 void ConnectWifi(const std::string& name,const std::string& password);
 void StartWeb();
 void UiTask();
 void WeatherTask();
 void Render();
 void Key(uint8_t key);
 void ShowBadge();
 bool SaveRegion(const char* json);
 std::string RegionJson();
 std::string SearchRegions(const std::string& query);
 std::string ScanWifi();
 static void WifiEvent(void*,const char*,int32_t,void*);
};
