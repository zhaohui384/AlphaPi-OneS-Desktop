#pragma once
#include <string>
#include <cmath>
#include "st7789.h"
namespace desktop_face {
inline void Oval(radio::Display& lcd,int cx,int cy,int rx,int ry,uint16_t color){
 for(int y=-ry;y<=ry;++y)for(int x=-rx;x<=rx;++x)
  if(x*x*ry*ry+y*y*rx*rx<=rx*rx*ry*ry)lcd.DrawPixel(cx+x,cy+y,color);
}
// No image buffers or decoder tasks: animate within the existing UI task.
inline void Draw(radio::Display& lcd,const std::string& emotion,int state,int64_t ms){
 const uint16_t ink=0x4204, yellow=0xff03, blush=0xfc51;
 const bool happy=emotion=="happy"||emotion=="laughing"||emotion=="funny"||emotion=="loving";
 const bool sad=emotion=="sad"||emotion=="crying";
 const bool surprised=emotion=="surprised"||emotion=="shocked";
 const bool thinking=state==4||emotion=="thinking"||emotion=="confused";
 const bool blink=(ms%4300)>4100;
 Oval(lcd,80,50,20,20,0xecc0);Oval(lcd,80,49,19,19,yellow);
 for(int cx:{73,87}){
  if(happy&&!blink){for(int x=-3;x<=3;++x)lcd.FillRect(cx+x,45+x*x/4,1,2,ink);}
  else Oval(lcd,cx+(thinking?1:0),46,2,blink?1:3,ink);
 }
 if(state==6)Oval(lcd,80,57,4,2+(ms/140)%4,ink);
 else if(surprised)Oval(lcd,80,57,3,4,ink);
 else if(thinking){for(int i=0;i<3;++i)Oval(lcd,75+i*5,57,1,1,(ms/250)%3==i?ink:0xd4a2);}
 else for(int x=-6;x<=6;++x)lcd.FillRect(80+x,(sad?61:56)+(sad?-1:1)*(36-x*x)/10,1,2,ink);
 if(happy){Oval(lcd,67,54,3,2,blush);Oval(lcd,93,54,3,2,blush);}
 if(emotion=="crying"){Oval(lcd,69,55,2,4,0x65ff);Oval(lcd,91,55,2,4,0x65ff);}
 if(state==5){int h=2+(ms/180)%3;lcd.FillRect(55,47-h,2,h*2,0x7bef);lcd.FillRect(103,47-h,2,h*2,0x7bef);}
}
}
