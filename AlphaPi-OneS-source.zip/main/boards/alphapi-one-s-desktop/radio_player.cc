#include "radio_player.h"

#include <algorithm>
#include <array>
#include <cstring>
#include <vector>

#include "esp_heap_caps.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "freertos/idf_additions.h"
#include "freertos/task.h"

#include "simple_dec/esp_audio_simple_dec.h"
#include "simple_dec/esp_audio_simple_dec_default.h"
#include "decoder/impl/esp_mp3_dec.h"

namespace radio {
namespace {

constexpr char kTag[] = "RadioPlayer";
constexpr size_t kNetworkReadBytes = 2048;
constexpr size_t kDecoderInputBytes = 8192;
constexpr size_t kDecoderOutputBytes = 12288;

// IDF 6.0.1 vStreamBufferDeleteWithCaps incorrectly calls vSemaphoreDelete.
// Retrieve its static allocations and use the stream-buffer deletion API.
void DeleteStreamBuffer(StreamBufferHandle_t buffer) {
    uint8_t* storage = nullptr;
    StaticStreamBuffer_t* control = nullptr;
    const auto result = xStreamBufferGetStaticBuffers(buffer, &storage, &control);
    configASSERT(result == pdTRUE);
    if (result != pdTRUE) return;
    vStreamBufferDelete(buffer);
    heap_caps_free(control);
    heap_caps_free(storage);
}

bool IsHttpUrl(const char* url) {
    return url != nullptr &&
           (std::strncmp(url, "http://", 7) == 0 ||
            std::strncmp(url, "https://", 8) == 0);
}

// 把数据完整写入 StreamBuffer，期间若流代次变化则提前退出
void SendAll(StreamBufferHandle_t buffer, const uint8_t* data, size_t length,
             const std::atomic<uint32_t>& generation,
             uint32_t expected_generation) {
    size_t sent = 0;
    while (sent < length && generation.load() == expected_generation) {
        sent += xStreamBufferSend(buffer, data + sent, length - sent,
                                  pdMS_TO_TICKS(250));
    }
}

}  // namespace

RadioPlayer::~RadioPlayer() { Stop(); }

const char* RadioPlayer::station_name() const {
    const int index =
        std::clamp(station_index_.load(), 0, kDefaultStationCount - 1);
    return kDefaultStations[index].name;
}

size_t RadioPlayer::pcm_available() const {
    if (pcm_buffer_ == nullptr) {
        return 0;
    }
    return xStreamBufferBytesAvailable(pcm_buffer_);
}

void RadioPlayer::SetState(PlayerState state, const char* status) {
    state_.store(state);
    if (status != nullptr) {
        std::strncpy(status_text_, status, sizeof(status_text_) - 1);
        status_text_[sizeof(status_text_) - 1] = '\0';
    }
}

void RadioPlayer::RestartStream() { generation_.fetch_add(1); }

bool RadioPlayer::Start() {
    if (running_.load()) {
        return true;
    }
    if(active_tasks_.load()!=0)return false;

    if (!compressed_buffer_) compressed_buffer_ = xStreamBufferCreateWithCaps(
        kCompressedBufferBytes, 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!pcm_buffer_) pcm_buffer_ = xStreamBufferCreateWithCaps(
        kPcmBufferBytes, kPlaybackChunkSamples * sizeof(int16_t),
        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (compressed_buffer_ == nullptr || pcm_buffer_ == nullptr) {
        ESP_LOGE(kTag, "流缓冲分配失败");
        SetState(PlayerState::kError,"BUFFER ALLOCATION FAILED");
        return false;
    }

    audio_.Init();
    audio_.SetVolume(volume_.load());
    starting_.store(true);
    active_tasks_.store(3);

    // 三个任务的栈都留足余量：
    //   DecoderTask 里 8KB 输入缓冲 + 解码库自身开销，给 10KB；
    //   NetworkTask 里 2KB 收流缓冲 + esp_http_client 内部开销，给 8KB；
    //   PlaybackTask 只有 960 字节的样本块，但 UART 驱动与日志也有开销，给 5KB。
    const BaseType_t net = xTaskCreate(NetworkTaskEntry, "radio_net", 6144,
                                       this, 5, nullptr);
    const BaseType_t dec = xTaskCreate(DecoderTaskEntry, "radio_decode", 8192,
                                       this, 6, nullptr);
    const BaseType_t play = xTaskCreate(PlaybackTaskEntry, "radio_play", 4096,
                                        this, 7, nullptr);
    if (net != pdPASS || dec != pdPASS || play != pdPASS) {
        ESP_LOGE(kTag, "任务创建失败");
        running_.store(false);
        active_tasks_.fetch_sub((net!=pdPASS)+(dec!=pdPASS)+(play!=pdPASS));
        starting_.store(false);
        SetState(PlayerState::kError,"TASK ALLOCATION FAILED");
        return false;
    }

    running_.store(true);
    starting_.store(false);
    ESP_LOGI(kTag, "收音机已启动，共 %d 个电台", kDefaultStationCount);
    return true;
}

void RadioPlayer::Stop() {
    if (!running_.load()) {
        return;
    }
    running_.store(false);
    paused_.store(true);
    generation_.fetch_add(1);
    audio_.Stop();
    SetState(PlayerState::kIdle, "STOPPED");
}

void RadioPlayer::Play() {
    if (!running_.load() && !Start()) {
        return;
    }
    paused_.store(false);
    SetState(PlayerState::kConnecting,"CONNECTING");
    RestartStream();
}

void RadioPlayer::ReleaseStoppedBuffers(){
    if(running_.load() || starting_.load() || active_tasks_.load()!=0)return;
    if(compressed_buffer_){auto buffer=compressed_buffer_;compressed_buffer_=nullptr;DeleteStreamBuffer(buffer);}
    if(pcm_buffer_){auto buffer=pcm_buffer_;pcm_buffer_=nullptr;DeleteStreamBuffer(buffer);}
}

void RadioPlayer::Pause() {
    paused_.store(true);
    generation_.fetch_add(1);
    SetState(PlayerState::kPaused, "PAUSED");
}

void RadioPlayer::TogglePlayPause() {
    if (paused_.load()) {
        Play();
    } else {
        Pause();
    }
}

void RadioPlayer::NextStation() {
    const int next = (station_index_.load() + 1) % kDefaultStationCount;
    station_index_.store(next);
    if (!paused_.load()) {
        RestartStream();
    }
}

void RadioPlayer::PreviousStation() {
    const int prev =
        (station_index_.load() + kDefaultStationCount - 1) % kDefaultStationCount;
    station_index_.store(prev);
    if (!paused_.load()) {
        RestartStream();
    }
}

void RadioPlayer::SetVolume(int volume) {
    const int v = std::clamp(volume, kVolumeMin, kVolumeMax);
    volume_.store(v);
    audio_.SetVolume(v);
}

// ---------------------------------------------------------------------------
// 任务入口
// ---------------------------------------------------------------------------
void RadioPlayer::NetworkTaskEntry(void* context) {
    while(static_cast<RadioPlayer*>(context)->starting_.load())vTaskDelay(pdMS_TO_TICKS(10));
    static_cast<RadioPlayer*>(context)->NetworkTask();
    // Return through task-local C++ destructors before reporting completion.
    static_cast<RadioPlayer*>(context)->active_tasks_.fetch_sub(1);
    vTaskDelete(nullptr);
}
void RadioPlayer::DecoderTaskEntry(void* context) {
    while(static_cast<RadioPlayer*>(context)->starting_.load())vTaskDelay(pdMS_TO_TICKS(10));
    static_cast<RadioPlayer*>(context)->DecoderTask();
    // Return through task-local C++ destructors before reporting completion.
    static_cast<RadioPlayer*>(context)->active_tasks_.fetch_sub(1);
    vTaskDelete(nullptr);
}
void RadioPlayer::PlaybackTaskEntry(void* context) {
    while(static_cast<RadioPlayer*>(context)->starting_.load())vTaskDelay(pdMS_TO_TICKS(10));
    static_cast<RadioPlayer*>(context)->PlaybackTask();
    // Return through task-local C++ destructors before reporting completion.
    static_cast<RadioPlayer*>(context)->active_tasks_.fetch_sub(1);
    vTaskDelete(nullptr);
}

// ---------------------------------------------------------------------------
// NetworkTask：HTTP 拉流 -> compressed_buffer_
// ---------------------------------------------------------------------------
void RadioPlayer::NetworkTask() {
    std::array<uint8_t, kNetworkReadBytes> buffer = {};
    uint32_t handled_generation = 0;

    while (running_.load()) {
        if (paused_.load()) {
            vTaskDelay(pdMS_TO_TICKS(100));
            continue;
        }
        const uint32_t current_generation = generation_.load();
        if (current_generation == handled_generation) {
            vTaskDelay(pdMS_TO_TICKS(50));
            continue;
        }
        handled_generation = current_generation;

        const int index =
            std::clamp(station_index_.load(), 0, kDefaultStationCount - 1);
        const Station& station = kDefaultStations[index];
        if (!IsHttpUrl(station.url)) {
            SetState(PlayerState::kError, "BAD URL");
            vTaskDelay(pdMS_TO_TICKS(1000));
            continue;
        }

        ESP_LOGI(kTag, "连接电台：%s", station.name);
        SetState(PlayerState::kConnecting, "CONNECTING");

        esp_http_client_config_t config = {};
        config.url = station.url;
        config.timeout_ms = 7000;
        config.buffer_size = 4096;
        config.buffer_size_tx = 1024;
        config.keep_alive_enable = true;
        // 电台表全部是明文 http，不需要 TLS 证书包

        esp_http_client_handle_t client = esp_http_client_init(&config);
        bool stream_ok = false;
        if (client != nullptr) {
            esp_http_client_set_header(client, "User-Agent",
                                       "AlphaPi-One-Radio/1.0");
            // 关掉 ICY 元数据，否则会夹杂在音频流里
            esp_http_client_set_header(client, "Icy-MetaData", "0");
            if (esp_http_client_open(client, 0) == ESP_OK) {
                esp_http_client_fetch_headers(client);
                const int status = esp_http_client_get_status_code(client);
                if (status >= 200 && status < 300) {
                    SetState(PlayerState::kBuffering, "BUFFERING");
                    while (running_.load() && !paused_.load() &&
                           generation_.load() == current_generation) {
                        const int count = esp_http_client_read(
                            client, reinterpret_cast<char*>(buffer.data()),
                            buffer.size());
                        if (count > 0) {
                            SendAll(compressed_buffer_, buffer.data(), count,
                                    generation_, current_generation);
                            stream_ok = true;
                        } else {
                            break;
                        }
                    }
                } else {
                    ESP_LOGW(kTag, "电台返回 HTTP %d", status);
                }
                esp_http_client_close(client);
            }
            esp_http_client_cleanup(client);
        }

        if (running_.load() && !paused_.load() &&
            generation_.load() == current_generation) {
            SetState(PlayerState::kReconnecting,
                     stream_ok ? "RECONNECTING" : "STREAM ERROR");
            vTaskDelay(pdMS_TO_TICKS(stream_ok ? 1000 : 2500));
            generation_.fetch_add(1);
        }
    }
}

// ---------------------------------------------------------------------------
// DecoderTask：MP3 解码 + 重采样 -> pcm_buffer_
// ---------------------------------------------------------------------------
void RadioPlayer::DecoderTask() {
    esp_audio_simple_dec_register_default();
    // 预编译 libesp_audio_simple_dec.a 的默认注册表只含 WAV/M4A/TS/OGG，
    // MP3 解码器(esp_mp3_dec)在主库存在但未注册 -> open 返回 NOT_SUPPORT(-7)。
    // 显式注册后 simple_dec 才能按类型找到 MP3 解码器。
    esp_mp3_dec_register();

    // 输入缓存在堆上：8KB 放栈上会直接撑爆任务栈。
    std::vector<uint8_t> input(kDecoderInputBytes);
    std::vector<uint8_t> decoded(kDecoderOutputBytes);
    std::vector<int16_t> mono(kDecoderOutputBytes / sizeof(int16_t));
    std::vector<int16_t> resampled;

    uint32_t active_generation = 0;
    esp_audio_simple_dec_handle_t decoder = nullptr;
    uint32_t converter_src_rate = 0;
    size_t buffered = 0;

    auto drain_compressed = [this]() {
        std::array<uint8_t, 512> sink = {};
        while (xStreamBufferReceive(compressed_buffer_, sink.data(),
                                    sink.size(), 0) > 0) {
        }
    };

    while (running_.load()) {
        const uint32_t current_generation = generation_.load();
        if (current_generation != active_generation) {
            active_generation = current_generation;
            buffered = 0;
            drain_compressed();
            if (decoder != nullptr) {
                esp_audio_simple_dec_close(decoder);
                decoder = nullptr;
            }
            esp_audio_simple_dec_cfg_t cfg = {};
            cfg.dec_type = ESP_AUDIO_SIMPLE_DEC_TYPE_MP3;
            cfg.use_frame_dec = false;
            if (esp_audio_simple_dec_open(&cfg, &decoder) != ESP_AUDIO_ERR_OK) {
                SetState(PlayerState::kError, "DECODER ERROR");
                vTaskDelay(pdMS_TO_TICKS(1000));
                continue;
            }
        }

        if (paused_.load() || decoder == nullptr) {
            vTaskDelay(pdMS_TO_TICKS(50));
            continue;
        }

        if (buffered < input.size()) {
            buffered += xStreamBufferReceive(compressed_buffer_,
                                             input.data() + buffered,
                                             input.size() - buffered,
                                             pdMS_TO_TICKS(100));
        }
        if (buffered == 0 || generation_.load() != active_generation) {
            continue;
        }

        esp_audio_simple_dec_raw_t raw = {};
        raw.buffer = input.data();
        raw.len = buffered;
        esp_audio_simple_dec_out_t out = {};
        out.buffer = decoded.data();
        out.len = decoded.size();
        const esp_audio_err_t result =
            esp_audio_simple_dec_process(decoder, &raw, &out);

        if (result == ESP_AUDIO_ERR_BUFF_NOT_ENOUGH &&
            out.needed_size > decoded.size()) {
            decoded.resize(out.needed_size);
            continue;
        }
        if (result != ESP_AUDIO_ERR_OK && result != ESP_AUDIO_ERR_DATA_LACK) {
            ESP_LOGW(kTag, "MP3 解码错误 %d", result);
        }

        if (raw.consumed > 0 && raw.consumed <= buffered) {
            buffered -= raw.consumed;
            std::memmove(input.data(), input.data() + raw.consumed, buffered);
        }
        if (out.decoded_size == 0) {
            // 输入塞满却一个样本都解不出，丢弃避免死循环
            if (raw.consumed == 0 && buffered == input.size()) {
                buffered = 0;
            }
            continue;
        }

        esp_audio_simple_dec_info_t info = {};
        if (esp_audio_simple_dec_get_info(decoder, &info) != ESP_AUDIO_ERR_OK ||
            info.bits_per_sample != 16 || info.channel == 0 ||
            info.channel > 2) {
            SetState(PlayerState::kError, "FORMAT ERROR");
            continue;
        }

        const auto* samples = reinterpret_cast<const int16_t*>(decoded.data());
        const size_t frames = out.decoded_size / sizeof(int16_t) / info.channel;
        if (mono.size() < frames) {
            mono.resize(frames);
        }
        if (info.channel == 1) {
            std::memcpy(mono.data(), samples, frames * sizeof(int16_t));
        } else {
            // 立体声混单声道
            for (size_t i = 0; i < frames; ++i) {
                mono[i] = static_cast<int16_t>(
                    (static_cast<int32_t>(samples[i * 2]) +
                     static_cast<int32_t>(samples[i * 2 + 1])) /
                    2);
            }
        }

        const int16_t* pcm = mono.data();
        size_t pcm_frames = frames;
        if (info.sample_rate != kOutputSampleRate) {
            if (resampler_.src_rate() != info.sample_rate) {
                resampler_.Configure(info.sample_rate, kOutputSampleRate);
                converter_src_rate = info.sample_rate;
                ESP_LOGI(kTag, "重采样 %u -> %u Hz", info.sample_rate,
                         kOutputSampleRate);
            }
            const size_t capacity = resampler_.OutputCapacityFor(frames);
            if (resampled.size() < capacity) {
                resampled.resize(capacity);
            }
            pcm_frames =
                resampler_.Process(mono.data(), frames, resampled.data(),
                                   capacity);
            pcm = resampled.data();
        } else if (converter_src_rate != 0) {
            // 采样率回到直通，重置重采样器状态
            resampler_.Configure(kOutputSampleRate, kOutputSampleRate);
            converter_src_rate = 0;
        }

        if (pcm_frames > 0) {
            SendAll(pcm_buffer_, reinterpret_cast<const uint8_t*>(pcm),
                    pcm_frames * sizeof(int16_t), generation_,
                    active_generation);
        }
    }

    if (decoder != nullptr) {
        esp_audio_simple_dec_close(decoder);
    }
}

// ---------------------------------------------------------------------------
// PlaybackTask：pcm_buffer_ -> N32
// ---------------------------------------------------------------------------
void RadioPlayer::PlaybackTask() {
    std::array<int16_t, kPlaybackChunkSamples> samples = {};
    bool pause_stopped=false;
    uint32_t active_generation = 0;
    bool started = false;

    auto drain_pcm = [this]() {
        std::array<uint8_t, 512> sink = {};
        while (xStreamBufferReceive(pcm_buffer_, sink.data(), sink.size(), 0) >
               0) {
        }
    };

    while (running_.load()) {
        const uint32_t current_generation = generation_.load();
        if (current_generation != active_generation) {
            active_generation = current_generation;
            started = false;
            drain_pcm();
        }
        if (paused_.load()) {
            if(!pause_stopped){audio_.Stop();pause_stopped=true;}
            vTaskDelay(pdMS_TO_TICKS(50));
            continue;
        }

        const size_t available = xStreamBufferBytesAvailable(pcm_buffer_);
        pause_stopped=false;
        const size_t threshold =
            started ? kRebufferBytes : kInitialPrebufferBytes;
        if (!started && available < threshold) {
            SetState(PlayerState::kBuffering, "BUFFERING");
            vTaskDelay(pdMS_TO_TICKS(50));
            continue;
        }
        started = true;

        const size_t received =
            xStreamBufferReceive(pcm_buffer_, samples.data(),
                                 samples.size() * sizeof(int16_t),
                                 pdMS_TO_TICKS(150));
        if (received == 0) {
            started = false;
            SetState(PlayerState::kBuffering, "REBUFFERING");
            continue;
        }

        const int sample_count = received / sizeof(int16_t);
        if (audio_.Write(samples.data(), sample_count) != sample_count) {
            // 写失败后 N32Audio 内部已重置链路（configured_=false），
            // 下次 Write 会重新发 WAV 头。退避 300ms 防止高频重置风暴。
            started = false;
            SetState(PlayerState::kReconnecting, "AUDIO RETRY");
            vTaskDelay(pdMS_TO_TICKS(300));
            continue;
        }
        SetState(PlayerState::kPlaying, "ON AIR");
    }
}

}  // namespace radio
