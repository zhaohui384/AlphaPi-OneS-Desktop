#pragma once

// 网络收音机播放器 —— AlphaPi One (ESP32-S3) 移植版
//
// 架构沿用 One S 版已验证的四段流水线（各段独立任务，用 StreamBuffer 串联）：
//
//   NetworkTask  ──compressed_buffer──>  DecoderTask  ──pcm_buffer──>  PlaybackTask
//   (HTTP 收流)      (64KB, PSRAM)      (MP3解码+重采样)  (3秒 PCM)     (写 N32)
//
// 与 One S 版的差异：
//   - 重采样改用自研 Q16 定点插值（q16_resampler.h），
//     不再依赖有跨系转换缺陷的 esp_ae_rate_cvt
//   - 音频输出改用 N32Audio（n32_audio.h）
//   - 去掉了 display / wifi / settings 依赖：
//     屏幕由 xiaozhi 的 Display 管理，Wi-Fi 由 WifiBoard 管理，
//     电台表先用内置的实测列表（后续可接 NVS 让用户自定义）

#include <atomic>
#include <cstdint>

#include "freertos/FreeRTOS.h"
#include "freertos/stream_buffer.h"

#include "n32_audio.h"
#include "q16_resampler.h"
#include "radio_config.h"

namespace radio {

class RadioPlayer {
public:
    RadioPlayer() = default;
    ~RadioPlayer();

    // 创建缓冲与任务。Start() 之后默认处于暂停态，需显式 Play()。
    bool Start();
    void Stop();

    void Play();
    void Pause();
    void TogglePlayPause();
    bool paused() const { return paused_.load(); }

    void NextStation();
    void PreviousStation();

    // volume: 0..100（ONE 的 N32 固件直接接受这个范围）
    void SetVolume(int volume);
    int volume() const { return volume_.load(); }

    PlayerState state() const { return state_.load(); }
    const char* status_text() const { return status_text_; }
    int station_index() const { return station_index_.load(); }
    int station_count() const { return kDefaultStationCount; }
    const char* station_name() const;

    bool running() const { return running_.load(); }
    int active_tasks() const { return active_tasks_.load(); }
    void ReleaseStoppedBuffers();

    // PCM 缓冲当前可用字节数 / 容量。
    // 按键任务用它判断"现在占用总线读键是否安全"：
    // 缓冲充裕时读键造成的 1ms 空洞无所谓，欠载边缘时绝不能读。
    // xStreamBufferBytesAvailable 可从任意任务调用。
    size_t pcm_available() const;
    size_t pcm_capacity() const { return kPcmBufferBytes; }
    bool HasPlaybackSlack() const {
        return pcm_available() >= kKeyPollSlackBytes;
    }

private:
    void NetworkTask();
    void DecoderTask();
    void PlaybackTask();

    static void NetworkTaskEntry(void* context);
    static void DecoderTaskEntry(void* context);
    static void PlaybackTaskEntry(void* context);

    void SetState(PlayerState state, const char* status);
    void RestartStream();

    StreamBufferHandle_t compressed_buffer_ = nullptr;
    StreamBufferHandle_t pcm_buffer_ = nullptr;

    N32Audio audio_;
    Q16Resampler resampler_;

    std::atomic<bool> running_{false};
    std::atomic<bool> starting_{false};
    std::atomic<int> active_tasks_{0};
    std::atomic<bool> paused_{true};
    std::atomic<PlayerState> state_{PlayerState::kIdle};
    std::atomic<int> station_index_{0};
    std::atomic<int> volume_{kDefaultVolume};
    std::atomic<uint32_t> generation_{0};

    char status_text_[24] = "WAITING";
};

}  // namespace radio
