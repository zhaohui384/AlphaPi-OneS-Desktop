#pragma once

// N32 音频协处理器输出 —— AlphaPi One (ESP32-S3) 独立版
//
// 移植自 xiaozhi-esp32/main/radio/n32_audio.{h,cc}，改动：
//   1. 去掉对 alphapi_s3_audio_codec.h 的依赖（UART 互斥锁在本模块内定义）
//   2. 新增 Init()：本模块自己完成 uart_driver_install（原由板级 codec 负责）
//
// 保留两个已被实机验证的关键做法：
//   1. 16-bit 有符号 -> 8-bit 无符号转换 (sample + 32768) >> 8
//   2. 播放前发送 44 字节 WAV 头，向 N32 声明 24000Hz / 8bit / mono

#include <atomic>
#include <cstddef>
#include <cstdint>

#include "radio_config.h"

namespace radio {

class N32Audio {
public:
    N32Audio() = default;

    // 初始化 UART 并设置初始音量。必须在任何读写之前调用一次。
    bool Init();

    // 进入播放态：停录音、设音量、发 WAV 头。
    // 会在第一次 Write() 时自动调用，也可提前手动调用。
    bool Start();
    void Stop();

    void SetVolume(int volume);
    int volume() const { return volume_; }

    // 写入 16-bit 有符号单声道 PCM，内部转换并分块发给 N32。
    // 返回实际写入的样本数（正常情况下等于 sample_count）。
    int Write(const int16_t* samples, int sample_count);

    // 读取按键寄存器（0x00）。
    // 返回位掩码：A=0x04 B=0x08 L=0x02 R=0x01，按下为 1（原板实测）。
    // 读取失败返回 0xFF。与音频写入共用同一把 UART 互斥锁，
    // 播放中读键会造成约 1ms 的音频空洞，调用方需自行判断时机。
    uint8_t ReadKeys();
    uint32_t key_polls() const;
    uint8_t cached_keys() const;
    int ReadMic(int16_t* samples, int count);

private:
    // 以下 *Locked 版本假定调用方已持有 UART 互斥锁，内部不再加锁。
    bool StartLocked();
    uint8_t ReadKeysLocked();
    void PollKeysLocked();
    bool SetHardwareVolumeLocked(int volume);

    bool SendCommand(uint8_t reg, const uint8_t* payload, size_t payload_size,
                     uint8_t* accepted = nullptr);
    bool ReadExact(uint8_t* data, size_t length, int timeout_ms);
    static uint8_t Checksum(const uint8_t* data, size_t length);

    bool initialized_ = false;
    bool configured_ = false;
    std::atomic<int> volume_{kDefaultVolume};
};

}  // namespace radio
