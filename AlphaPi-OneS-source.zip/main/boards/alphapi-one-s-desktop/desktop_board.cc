#include "settings.h"
#include "esp_timer.h"
#include <unistd.h>
#include <fcntl.h>
#include "desktop_runtime.h"
#include "desktop_assets.h"
#include "desktop_home.h"
#include "desktop_face.h"
#include "application.h"
#include "wifi_board.h"
#include "esp_wifi.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <ctime>
#include <cstdio>
std::atomic<int> desktop_page{0};
std::atomic<bool> desktop_network{false};
DesktopRuntime* DesktopRuntime::instance=nullptr;
namespace {
uint16_t Color(int r,int g,int b){return ((r>>3)<<11)|((g>>2)<<5)|(b>>3);}
uint32_t Codepoint(const char*& p){uint8_t c=*p++;if(c<128)return c;if((c&224)==192){uint32_t a=c&31;if(!*p)return '?';return (a<<6)|(*p++&63);}if((c&240)==224){uint32_t a=c&15;if(!p[0]||!p[1]){while(*p)++p;return '?';}a=(a<<6)|(*p++&63);return (a<<6)|(*p++&63);}return '?';}
int Text(radio::Display& lcd,int x,int y,const std::string& s,uint16_t color,int right=158,int bottom=128,bool wrap=false){
 int start=x;const char* p=s.c_str();
 while(*p){auto code=Codepoint(p);if(code=='\n'){x=start;y+=14;continue;}
 auto first=std::lower_bound(std::begin(desk_glyphs),std::end(desk_glyphs),code,[](const DeskGlyph& g,uint32_t c){return g.code<c;});
 if(first==std::end(desk_glyphs)||first->code!=code)continue;
 int width=first->width;if(x+width>right){if(!wrap)break;x=start;y+=14;}if(y+13>bottom)break;
 for(int yy=0;yy<13;yy++)for(int xx=0;xx<width;xx++)if(first->rows[yy]&(1<<(width-1-xx)))lcd.DrawPixel(x+xx,y+yy,color);
 x+=width;
 }
 return x;
}
bool Rounded(int x,int y,int w,int h,int r){int dx=x<r?r-x:x>=w-r?x-(w-r-1):0;int dy=y<r?r-y:y>=h-r?y-(h-r-1):0;return dx*dx+dy*dy<=r*r;}
void Focus(radio::Display& lcd,int x,int y){for(int yy=0;yy<34;yy++)for(int xx=0;xx<34;xx++)if(Rounded(xx,yy,34,34,10)&&!(xx>0&&yy>0&&xx<33&&yy<33&&Rounded(xx-1,yy-1,32,32,9)))lcd.DrawPixel(x+xx,y+yy,Color(218,199,255));}
void Background(radio::Display& lcd){
 static const auto pixels=[](){std::array<uint16_t,160*128> p{};for(int y=0;y<128;y++)for(int x=0;x<160;x++){float dx=(x-125)/100.0f,dy=(y-100)/90.0f;float glow=std::max(0.0f,1-dx*dx-dy*dy);p[y*160+x]=Color(10+y*11/128+glow*18,19+y*4/128+glow*7,39+y*12/128+glow*27);}return p;}();
 for(int y=0;y<128;y++)for(int x=0;x<160;x++)lcd.DrawPixel(x,y,pixels[y*160+x]);
}
}
DesktopRuntime::DesktopRuntime(){instance=this;dirty=true;}
void DesktopActivationCode(const std::string& code){auto s=DesktopRuntime::instance;if(!s)return;std::lock_guard<std::recursive_mutex>l(s->display.mutex);s->display.activation=code;s->dirty=true;}
void DesktopRuntime::ShowBadge(){
 FILE* f=fopen("/data/badge.bin","rb");if(!f){rename("/data/badge.old","/data/badge.bin");f=fopen("/data/badge.bin","rb");}
 if(f){uint8_t h[8]={};bool ok=fread(h,1,8,f)==8&&!memcmp(h,"BDG1",4);int w=h[4]|(h[5]<<8),height=h[6]|(h[7]<<8);ok=ok&&((w==160&&height==128)||(w==128&&height==160));if(ok){uint8_t line[320];for(int y=0;y<height;y++){if(fread(line,1,w*2,f)!=(size_t)(w*2)){ok=false;break;}for(int x=0;x<w;x++){uint16_t c=line[2*x]|(line[2*x+1]<<8);if(w==160)display.lcd.DrawPixel(x,y,c);else display.lcd.DrawPixel(y,127-x,c);}}}fclose(f);if(ok)return;}
 auto& lcd=display.lcd;Text(lcd,12,15,"我的电子吧唧",Color(235,222,255));Text(lcd,12,39,"手机连接设备热点",0xffff);Text(lcd,12,57,"AlphaPi-Desk",0xffff);Text(lcd,12,74,"密码 alphapi88",Color(187,198,220));Text(lcd,12,91,"192.168.4.1",0xffff);Text(lcd,12,111,"B 返回桌面",Color(160,170,190));
}
void DesktopRuntime::Render(){
 auto& lcd=display.lcd;std::lock_guard<std::recursive_mutex> lock(display.mutex);Background(lcd);const auto white=Color(245,247,255),muted=Color(183,192,216),accent=Color(176,146,240);char buffer[100];int page=desktop_page.load();
 if(page==0){
  time_t now=time(nullptr);tm t={};localtime_r(&now,&t);bool valid=t.tm_year+1900>=2024;
  std::string place,condition;bool available;double degrees;
  {std::lock_guard<std::mutex>s(state_mutex);place=city;condition=description;available=have_weather;degrees=temperature;}
  wifi_ap_record_t ap={};int signal=0;
  if(esp_wifi_sta_get_ap_info(&ap)==ESP_OK)signal=ap.rssi>=-55?4:ap.rssi>=-67?3:ap.rssi>=-78?2:1;
  desktop_home::Draw(lcd,t,valid,place,condition,available,degrees,signal);
  const char* labels[]={"吧唧","小智","收音机","设置"};const int xpos[]={10,48,86,124};
  for(int i=0;i<4;i++){for(int y=0;y<26;y++)for(int x=0;x<26;x++)lcd.DrawPixel(xpos[i]+x,84+y,desk_icons[i][y*26+x]);if(selected==i)Focus(lcd,xpos[i]-4,80);desktop_home::Text(lcd,xpos[i]+(i==2?-1:4),115,labels[i],i==selected?white:muted);}
 }else if(page==1){ShowBadge();}
 else if(page==2){
  lcd.FillRect(0,0,160,128,0xffff);
  const auto ink=Color(48,52,60),hint=Color(112,116,125);
  Text(lcd,8,4,display.status,ink,153,18,false);
  if(!display.activation.empty()){
   Text(lcd,9,28,"设备验证码",ink);
   int x=29;for(char c:display.activation){lcd.DrawCharScaled(x,49,c,ink,0xffff,2);x+=16;}
   Text(lcd,9,84,"请在小智网页绑定",hint);
  }else{
   desktop_face::Draw(lcd,display.emotion,Application::GetInstance().GetDeviceState(),esp_timer_get_time()/1000);
   Text(lcd,8,76,display.chat,ink,153,108,true);
  }
  Text(lcd,23,113,"A 对话  B 返回",hint);
 }else if(page==3){
  Text(lcd,9,7,"网络收音机",white);snprintf(buffer,sizeof(buffer),"%02d / %02d",radio.station_index()+1,radio.station_count());Text(lcd,110,7,buffer,muted);
  Text(lcd,12,34,radio.station_name(),white,149,75,true);
  const char* radio_status="等待播放"; switch(radio.state()){case radio::PlayerState::kConnecting:radio_status="正在连接";break;case radio::PlayerState::kBuffering:radio_status="正在缓冲";break;case radio::PlayerState::kPlaying:radio_status="正在播放";break;case radio::PlayerState::kPaused:radio_status="已暂停";break;case radio::PlayerState::kReconnecting:radio_status="正在重连";break;case radio::PlayerState::kError:radio_status="电台暂不可用";break;default:break;} Text(lcd,12,78,radio_status,accent);
  Text(lcd,9,99,"C/D 切台  A 播放暂停",muted);Text(lcd,9,113,"B 返回桌面",muted);
 }else if(page==4){
  Text(lcd,9,5,"手机设置",white);Text(lcd,9,27,"连接设备热点",muted);Text(lcd,9,44,"AlphaPi-Desk",white);Text(lcd,9,61,"密码 alphapi88",muted);Text(lcd,9,78,"192.168.4.1",white);Text(lcd,9,95,"图片 天气地区 Wi-Fi",accent);Text(lcd,9,113,"A 开启热点  B 返回",muted);
 }
 if(esp_timer_get_time()/1000 < volume_overlay_until){
  lcd.FillRect(34,3,92,29,Color(20,25,39));
  snprintf(buffer,sizeof(buffer),"音量 %d%%",codec.audio.volume());Text(lcd,50,5,buffer,white);
  lcd.FillRect(43,23,74,3,Color(69,74,92));lcd.FillRect(43,23,74*codec.audio.volume()/100,3,accent);
 }
 lcd.Flush();
}
void DesktopRuntime::SetVolume(int value){
 value=std::clamp(value,0,100);
 if(value!=codec.audio.volume()){
  codec.SetOutputVolume(value);radio.SetVolume(value);
  volume_save_at=esp_timer_get_time()/1000+1500;
 }
 volume_overlay_until=esp_timer_get_time()/1000+1800;dirty=true;
}
void DesktopRuntime::Key(uint8_t key){
 int page=desktop_page.load();
 if(key&8){
  if(page==3){radio.Stop();radio_started=false;}
  if(page==2){Application::GetInstance().ExitDesktopVoice();voice_cleanup_pending=true;}
  voice_pending=false;radio_pending=false;voice_ready_at=0;desktop_page=0;dirty=true;return;
 }
 if(page==0){
  if(key&2)selected=(selected+3)%4;if(key&1)selected=(selected+1)%4;
  if(key&4){desktop_page=selected+1;if(selected==0||selected==3)OpenAP();if(selected==1){radio.Stop();radio_started=false;voice_pending=true;voice_ready_at=0;display.SetStatus("正在切换小智");}if(selected==2){Application::GetInstance().ExitDesktopVoice();radio_pending=true;radio_ready_at=0;}}
 }else if(page==2){if((key&4)&&!voice_pending)Application::GetInstance().ToggleChatState();}
 else if(page==3&&!radio_pending){if(key&2)radio.PreviousStation();if(key&1)radio.NextStation();if(key&4)radio.TogglePlayPause();}
 else if((page==1||page==4)&&(key&4))OpenAP();
 dirty=true;
}
void DesktopRuntime::UiTask(){
 uint8_t stable=0,candidate=0;int matches=0;
 int64_t previous_loop=0,last_render=0;
 int64_t held_since[2]={},adjusted_at[2]={};bool long_handled[2]={};

 for(;;){
  // UI never reads stdin: console driver timeouts must not delay physical keys.
  int64_t loop_start=esp_timer_get_time();
  if(previous_loop){auto gap=static_cast<uint32_t>(loop_start-previous_loop);ui_gap_us=gap;ui_max_gap_us=std::max(ui_max_gap_us.load(),gap);}
  previous_loop=loop_start;ui_loops++;
  auto raw=codec.audio.ReadKeys();
  auto pressed=(uint8_t)(raw==0xff?stable:(raw&15));
  if(pressed==candidate)matches++;else{candidate=pressed;matches=0;}
  int64_t now=esp_timer_get_time()/1000;
  if(!radio.running()&&radio.active_tasks()==0)radio.ReleaseStoppedBuffers();
  if(voice_cleanup_pending&&Application::GetInstance().DesktopVoiceStopped()){
   codec.audio.Stop();voice_cleanup_pending=false;
  }
  if(radio_pending&&desktop_page.load()==3){
   if(Application::GetInstance().DesktopVoiceStopped()){
    if(!radio_ready_at)radio_ready_at=now+100;
    if(now>=radio_ready_at){codec.audio.Stop();codec.EnableInput(false);codec.EnableOutput(false);radio_started=radio.Start();if(radio_started)radio.Play();radio_pending=false;dirty=true;}
   }else radio_ready_at=0;
  }
  if(voice_pending&&desktop_page.load()==2){
   if(radio.active_tasks()==0&&Application::GetInstance().DesktopVoiceStopped()){
    if(!voice_ready_at)voice_ready_at=now+100;
    if(now>=voice_ready_at){codec.audio.Stop();voice_pending=false;display.SetStatus("A 开始对话");Application::GetInstance().ActivateDesktopVoice();}
   }else voice_ready_at=0;
  }
  if(matches==2&&stable!=candidate){
   uint8_t newly=candidate&~stable,released=stable&~candidate;
   for(int i=0;i<2;i++){
    uint8_t mask=i==0?2:1;
    if(newly&mask){held_since[i]=now;adjusted_at[i]=0;long_handled[i]=false;}
    if((released&mask)&&!long_handled[i])Key(mask);
   }
   stable=candidate;
   if(newly&12)Key(newly&12);
  }
  for(int i=0;i<2;i++){
   uint8_t mask=i==0?2:1;
   if(raw!=0xff&&(stable&mask)&&now-held_since[i]>=650&&now-adjusted_at[i]>=200){
    long_handled[i]=true;adjusted_at[i]=now;
    SetVolume(codec.audio.volume()+(i==0?5:-5));
   }
  }
  if(volume_save_at&&now>=volume_save_at){
   Settings settings("desk_audio",true);settings.SetInt("volume",codec.audio.volume());
   Settings audio_settings("audio",true);audio_settings.SetInt("output_volume",codec.audio.volume());
   volume_save_at=0;
  }
  // A changed volume already marks the display dirty. Redraw once when hiding it.
  static bool overlay_visible=false;
  bool visible=now<volume_overlay_until;
  if(visible!=overlay_visible){dirty=true;overlay_visible=visible;}
  if(display.changed.exchange(false))dirty=true;
  if(now-last_render>=1000&&(desktop_page.load()==0||desktop_page.load()==3))dirty=true;
  if(desktop_page.load()==2&&now-last_render>=160)dirty=true;
  if(dirty.load()&&now-last_render>=80){
   dirty=false;auto started=esp_timer_get_time();Render();render_us=esp_timer_get_time()-started;last_render=now;
  }
  vTaskDelay(pdMS_TO_TICKS(20));
 }
}
class AlphaPiOneSDesktopBoard final : public WifiBoard {
 DesktopRuntime runtime_;
public:
 Display* GetDisplay()override{return &runtime_.display;}
 AudioCodec* GetAudioCodec()override{return &runtime_.codec;}
 void StartNetwork()override{runtime_.StartNetwork();}
 void SetNetworkEventCallback(NetworkEventCallback cb)override{runtime_.network_callback=std::move(cb);}
 const char* GetNetworkStateIcon()override{return "";}
 void SetPowerSaveLevel(PowerSaveLevel)override{esp_wifi_set_ps(WIFI_PS_NONE);}
 std::string GetBoardJson()override{return "{\"type\":\"wifi\",\"name\":\"alphapi-one-s-desktop\"}";}
 std::string GetDeviceStatusJson()override{return desktop_network?"{\"network\":\"connected\"}":"{\"network\":\"disconnected\"}";}
};
DECLARE_BOARD(AlphaPiOneSDesktopBoard)

