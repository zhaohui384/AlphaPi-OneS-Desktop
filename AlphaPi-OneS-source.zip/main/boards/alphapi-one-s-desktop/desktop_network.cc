#if __has_include("wifi_profile.private.h")
#include "wifi_profile.private.h"
#else
#define DESKTOP_INITIAL_SSID ""
#define DESKTOP_INITIAL_PASSWORD ""
#endif
#include "desktop_runtime.h"
#include "settings.h"
#include "esp_wifi.h"
#include "esp_wifi_default.h"
#include "esp_event.h"
#include "esp_netif_sntp.h"
#include "esp_crt_bundle.h"
#include "esp_http_client.h"
#include "esp_spiffs.h"
#include "cJSON.h"
#include <cmath>
#include <cstring>
#include <ctime>
#include <cstdio>
namespace {
std::string JsonString(cJSON* j){char* s=cJSON_PrintUnformatted(j);std::string result=s?s:"{}";free(s);cJSON_Delete(j);return result;}
std::string HttpGet(const std::string& url){
 struct Response {std::string data;bool overflow=false;} response;
 esp_http_client_config_t cfg={};cfg.url=url.c_str();cfg.timeout_ms=15000;cfg.crt_bundle_attach=esp_crt_bundle_attach;cfg.buffer_size=2048;cfg.addr_type=HTTP_ADDR_TYPE_INET;cfg.user_agent="AlphaPiDesktop/1.0";cfg.max_redirection_count=3;cfg.user_data=&response;
 cfg.event_handler=[](esp_http_client_event_t* event)->esp_err_t{
  if(event->event_id==HTTP_EVENT_ON_DATA && event->data_len>0 && esp_http_client_get_status_code(event->client)==200){
   auto result=static_cast<Response*>(event->user_data);
   if(result->data.size()+event->data_len>32768){result->overflow=true;return ESP_FAIL;}
   result->data.append(static_cast<const char*>(event->data),event->data_len);
  }
  return ESP_OK;
 };
 auto client=esp_http_client_init(&cfg);if(!client)return {};
 esp_http_client_set_header(client,"Accept","application/json");esp_http_client_set_header(client,"Accept-Encoding","identity");
 auto error=esp_http_client_perform(client);int status=esp_http_client_get_status_code(client);
 if(error!=ESP_OK||status!=200||response.overflow){printf("DESKTOP_HTTP error=%s status=%d url=%s\n",esp_err_to_name(error),status,url.c_str());response.data.clear();}
 esp_http_client_cleanup(client);return response.data;
}
const char* WeatherName(int code){if(code<2)return "晴";if(code==2)return "多云";if(code==3)return "阴";if(code<50)return "雾";if(code<70)return "雨";if(code<80)return "雪";if(code<90)return "阵雨";return "雷雨";}
}
void DesktopRuntime::StartNetwork(){
 esp_vfs_spiffs_conf_t fs={};fs.base_path="/data";fs.partition_label="storage";fs.max_files=5;fs.format_if_mount_failed=true;esp_vfs_spiffs_register(&fs);
 {Settings config("desk_weather",false);auto saved=config.GetString("region","");if(!saved.empty())SaveRegion(saved.c_str());}
 {Settings config("desk_wifi",false);ssid=config.GetString("ssid","");pass=config.GetString("password","");}
 if(ssid.empty() && strlen(DESKTOP_INITIAL_SSID)>0){ssid=DESKTOP_INITIAL_SSID;pass=DESKTOP_INITIAL_PASSWORD;Settings saved("desk_wifi",true);saved.SetString("ssid",ssid);saved.SetString("password",pass);}
 {Settings volume("desk_audio",false);SetVolume(volume.GetInt("volume",85));}
 esp_netif_init();auto err=esp_event_loop_create_default();if(err!=ESP_OK&&err!=ESP_ERR_INVALID_STATE)return;
 esp_netif_create_default_wifi_sta();esp_netif_create_default_wifi_ap();
 wifi_init_config_t cfg=WIFI_INIT_CONFIG_DEFAULT();ESP_ERROR_CHECK(esp_wifi_init(&cfg));esp_wifi_set_storage(WIFI_STORAGE_RAM);
 esp_event_handler_register(WIFI_EVENT,ESP_EVENT_ANY_ID,WifiEvent,this);esp_event_handler_register(IP_EVENT,IP_EVENT_STA_GOT_IP,WifiEvent,this);
 ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
 if(!ssid.empty()){wifi_config_t station={};strncpy((char*)station.sta.ssid,ssid.c_str(),sizeof(station.sta.ssid));strncpy((char*)station.sta.password,pass.c_str(),sizeof(station.sta.password));esp_wifi_set_config(WIFI_IF_STA,&station);}
 ESP_ERROR_CHECK(esp_wifi_start());esp_wifi_set_ps(WIFI_PS_NONE);
 StartWeb();
 if(ssid.empty())OpenAP();
 xTaskCreate([](void* p){static_cast<DesktopRuntime*>(p)->UiTask();},"desktop_ui",6144,this,3,nullptr);
 xTaskCreate([](void* p){static_cast<DesktopRuntime*>(p)->WeatherTask();},"desktop_weather",8192,this,1,nullptr);
}
void DesktopRuntime::WifiEvent(void* arg, const char* base, int32_t id, void* data) {
    auto& self = *static_cast<DesktopRuntime*>(arg);
    if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        desktop_network = true;
        self.weather_refresh = true;
        if (self.network_callback)
            self.network_callback(NetworkEvent::Connected, self.ssid);
    }
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START && !self.ssid.empty())
        esp_wifi_connect();
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        desktop_network = false;
        auto event = static_cast<wifi_event_sta_disconnected_t*>(data);
        printf("DESKTOP_WIFI disconnected reason=%u scanning=%d\n", event ? event->reason : 0,
               self.wifi_scan_active.load());
        if (self.network_callback)
            self.network_callback(NetworkEvent::Disconnected, "");
        if (!self.ssid.empty() && !self.wifi_scan_active.load())
            esp_wifi_connect();
    }
    self.dirty = true;
}
void DesktopRuntime::OpenAP(){
 if(!ap_enabled){
  wifi_config_t ap={};strcpy((char*)ap.ap.ssid,"AlphaPi-Desk");strcpy((char*)ap.ap.password,"alphapi88");ap.ap.ssid_len=12;ap.ap.max_connection=3;ap.ap.authmode=WIFI_AUTH_WPA2_PSK;ap.ap.channel=6;
  esp_wifi_set_mode(WIFI_MODE_APSTA);esp_wifi_set_config(WIFI_IF_AP,&ap);ap_enabled=true;
 }
 StartWeb();dirty=true;
}
void DesktopRuntime::ConnectWifi(const std::string& name,const std::string& password){
 {Settings saved("desk_wifi",true);saved.SetString("ssid",name);saved.SetString("password",password);}
 ssid=name;pass=password;esp_wifi_disconnect();wifi_config_t station={};strncpy((char*)station.sta.ssid,name.c_str(),sizeof(station.sta.ssid));strncpy((char*)station.sta.password,password.c_str(),sizeof(station.sta.password));esp_wifi_set_config(WIFI_IF_STA,&station);esp_wifi_connect();dirty=true;
}
bool DesktopRuntime::SaveRegion(const char* json){
 auto root=cJSON_Parse(json);if(!root)return false;
 auto n=cJSON_GetObjectItem(root,"name"),la=cJSON_GetObjectItem(root,"latitude"),lo=cJSON_GetObjectItem(root,"longitude");
 bool valid=cJSON_IsString(n)&&strlen(n->valuestring)>0&&strlen(n->valuestring)<=60&&cJSON_IsNumber(la)&&cJSON_IsNumber(lo)&&std::isfinite(la->valuedouble)&&std::isfinite(lo->valuedouble)&&fabs(la->valuedouble)<=90&&fabs(lo->valuedouble)<=180;
 if(valid){std::lock_guard<std::mutex> lock(state_mutex);city=n->valuestring;latitude=la->valuedouble;longitude=lo->valuedouble;have_weather=false;description="正在更新";Settings saved("desk_weather",true);saved.SetString("region",json);weather_refresh=true;dirty=true;}
 cJSON_Delete(root);return valid;
}
std::string DesktopRuntime::RegionJson(){
 std::lock_guard<std::mutex> lock(state_mutex);auto root=cJSON_CreateObject();auto r=cJSON_AddObjectToObject(root,"region");cJSON_AddStringToObject(r,"name",city.c_str());cJSON_AddNumberToObject(r,"latitude",latitude);cJSON_AddNumberToObject(r,"longitude",longitude);return JsonString(root);
}
std::string DesktopRuntime::SearchRegions(const std::string& q){
 if(!desktop_network.load())return "{\"ok\":false,\"error\":\"设备尚未联网\"}";
 auto data=HttpGet("https://geocoding-api.open-meteo.com/v1/search?count=8&language=zh&format=json&name="+q);
 if(data.empty())return "{\"ok\":false,\"error\":\"城市搜索暂不可用\"}";
 return data;
}
std::string DesktopRuntime::ScanWifi() {
    if (wifi_scan_active.exchange(true))
        return "{\"ok\":false,\"error\":\"正在扫描，请稍候重试\"}";
    // A failing station connection otherwise keeps the driver busy and rejects scans.
    bool paused = !desktop_network.load();
    if (paused) {
        esp_wifi_disconnect();
        vTaskDelay(pdMS_TO_TICKS(150));
    }
    wifi_scan_config_t cfg = {};
    cfg.show_hidden = false;
    auto error = esp_wifi_scan_start(&cfg, true);
    wifi_scan_active = false;
    if (paused && !ssid.empty())
        esp_wifi_connect();
    if (error != ESP_OK) {
        printf("DESKTOP_WIFI scan error=%s\n", esp_err_to_name(error));
        return "{\"ok\":false,\"error\":\"扫描暂不可用，请直接输入 Wi-Fi 名称和密码\"}";
    }
    uint16_t count = 24;
    wifi_ap_record_t records[24] = {};
    if (esp_wifi_scan_get_ap_records(&count, records) != ESP_OK)
        return "{\"ok\":false,\"error\":\"读取扫描结果失败，请重试\"}";
    auto root = cJSON_CreateObject();
    auto list = cJSON_AddArrayToObject(root, "networks");
    for (int i = 0; i < count; i++) {
        auto item = cJSON_CreateObject();
        cJSON_AddStringToObject(item, "ssid", (char*)records[i].ssid);
        cJSON_AddNumberToObject(item, "rssi", records[i].rssi);
        cJSON_AddBoolToObject(item, "secure", records[i].authmode != WIFI_AUTH_OPEN);
        cJSON_AddItemToArray(list, item);
    }
    return JsonString(root);
}
void DesktopRuntime::WeatherTask() {
    bool ntp = false;
    time_t last = 0;
    for (;;) {
        if (desktop_network.load()) {
            if (!ntp) {
                setenv("TZ", "CST-8", 1);
                tzset();
                esp_sntp_config_t cfg = ESP_NETIF_SNTP_DEFAULT_CONFIG("ntp.aliyun.com");
                esp_netif_sntp_init(&cfg);
                ntp = true;
            }
            time_t now = time(nullptr);
            if (weather_refresh.exchange(false) || now - last > 1800) {
                double lat, lon;
                {std::lock_guard<std::mutex> lock(state_mutex);lat=latitude;lon=longitude;}
    char url[256];snprintf(url,sizeof(url),"https://api.open-meteo.com/v1/forecast?latitude=%.5f&longitude=%.5f&current=temperature_2m,relative_humidity_2m,weather_code",lat,lon);
    auto text=HttpGet(url);auto root=cJSON_Parse(text.c_str());auto current=cJSON_GetObjectItem(root,"current");auto temp=cJSON_GetObjectItem(current,"temperature_2m"),hum=cJSON_GetObjectItem(current,"relative_humidity_2m"),code=cJSON_GetObjectItem(current,"weather_code");
    {std::lock_guard<std::mutex> lock(state_mutex);if(lat==latitude&&lon==longitude&&cJSON_IsNumber(temp)&&cJSON_IsNumber(code)){temperature=temp->valuedouble;humidity=cJSON_IsNumber(hum)?hum->valueint:-1;description=WeatherName(code->valueint);have_weather=true;}else if(!have_weather)description="暂不可用";}
    cJSON_Delete(root);last=now;dirty=true;
   }
  }
  vTaskDelay(pdMS_TO_TICKS(1000));
 }
}
